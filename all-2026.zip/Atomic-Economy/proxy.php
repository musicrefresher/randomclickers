<?php
// PHP Proxy for Gemini API
// این فایل به گونه‌ای طراحی شده است که تنظیمات CORS را مستقیماً در PHP انجام دهد و وابستگی به .htaccess را حذف کند.

// -----------------------------------------------------------------------------
// !!! CRITICAL: REPLACE THIS WITH YOUR ACTUAL GEMINI API KEY !!!
// -----------------------------------------------------------------------------
$apiKey = "AIzaSyD5ZHCCdNm_MqXJLBrsdXzBiL57nlv-yhs"; 
// -------------------------------------------------------------

// --- Configuration ---
$model = "gemini-2.5-flash-preview-09-2025";
$apiUrl = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$apiKey}";

// --- Universal CORS Headers (Must be sent for ALL requests) ---
// Allow access from any origin (*)
header("Access-Control-Allow-Origin: *"); 
// Allow the required methods (POST for API call, OPTIONS for preflight)
header("Access-Control-Allow-Methods: POST, OPTIONS");
// Allow the required headers (Content-Type for JSON payload)
header("Access-Control-Allow-Headers: Content-Type");
// Indicate how long the browser can cache the preflight result (optional, but good practice)
header("Access-Control-Max-Age: 86400");
header('Content-Type: application/json');


// --- Handle Preflight Request (OPTIONS) ---
// If the browser sends an OPTIONS request, we only need to respond with 200 OK 
// and the CORS headers above.
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit(); 
}

// --- Main POST Request Handling ---
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    // If it's not OPTIONS (which we handled above) AND it's not POST, it's a 405 error.
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed. This endpoint only accepts POST requests.']);
    exit();
}


// Get the raw JSON POST data
$jsonPayload = file_get_contents('php://input');
if (empty($jsonPayload)) {
    http_response_code(400);
    echo json_encode(['error' => 'No request body found.']);
    exit();
}

// --- Forward Request to Gemini API ---

$ch = curl_init($apiUrl);

curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonPayload);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Accept: application/json'
]);

// Execute the request
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

// Check for cURL errors
if (curl_errno($ch)) {
    // If cURL fails to connect (e.g., DNS error, firewall blocking outbound traffic)
    http_response_code(500);
    echo json_encode(['error' => 'cURL Error: Could not connect to Gemini API. Check server firewall or cURL configuration. Details: ' . curl_error($ch)]);
} else {
    // Forward the API response (and HTTP status code) back to the client
    http_response_code($httpCode);
    echo $response;
}

curl_close($ch);
?>