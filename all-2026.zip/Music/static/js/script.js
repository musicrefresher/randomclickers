/* ============================
   Safe Random Player Script
   ============================ */

var app = {
  playlist: { id: 'PLt1KecuO3RM0ONHI6DDFiixvN-ZBrm8AP', max: 200 },
  index: 1,
  likes: {},
  baseURL: 'https://www.youtube.com/embed/?list={0}&index={1}',
  queryStrings: '&enablejsapi=1&wmode=transparent&autoplay=0&rel=0&showinfo=0&iv_load_policy=3&showsearch=0&autohide=1&controls=1'
};

function safeGet(id) { return document.getElementById(id); }

function saveLikes() {
  try { localStorage.setItem('videoLikes', JSON.stringify(app.likes)); } catch (e) {}
}

function loadLikes() {
  try {
    var s = localStorage.getItem('videoLikes');
    if (s) app.likes = JSON.parse(s) || {};
  } catch (e) { app.likes = {}; }
}

String.prototype.format = function() {
  var s = this.toString();
  for (var i = 0; i < arguments.length; i++) {
    s = s.replace(new RegExp('\\{' + i + '\\}','g'), arguments[i]);
  }
  return s;
};

function setURL() {
  return app.baseURL.format(app.playlist.id, app.index) + app.queryStrings;
}

function generateRandom(num) { return Math.floor(Math.random() * num); }

function getNextIndex() {
  var total = 0, weights = [];
  var max = Math.min(Math.max(parseInt(app.playlist.max,10)||200, 5), 500);
  for (var i = 1; i < max; i++) {
    var w = app.likes[i] ? 5 : 1;
    weights.push(w);
    total += w;
  }
  if (total <= 0) return 1;
  var r = generateRandom(total);
  for (var j = 0; j < weights.length; j++) {
    if (r < weights[j]) return j + 1;
    r -= weights[j];
  }
  return 1;
}

function updateLikeButtonUI() {
  var likeBtn = safeGet('likeButton'),
      likeText = safeGet('likeButtonText'),
      likeIcon = safeGet('likeIcon');
  if (!likeBtn) return;
  if (app.likes[app.index]) {
    likeBtn.classList.add('liked');
    if (likeText) likeText.textContent = 'Liked';
    if (likeIcon) { likeIcon.innerHTML = '&#xf164;'; likeIcon.style.color = 'green'; }
  } else {
    likeBtn.classList.remove('liked');
    if (likeText) likeText.textContent = 'Like';
    if (likeIcon) { likeIcon.innerHTML = '&#xf087;'; likeIcon.style.color = ''; }
  }
}

function iframeHas(listId, index) {
  var player = safeGet('player');
  if (!player || !player.src) return false;
  try {
    var url = new URL(player.src, location.origin);
    var params = new URLSearchParams(url.search);
    return params.get('list') === String(listId) && params.get('index') === String(index);
  } catch (e) { return false; }
}

document.addEventListener('DOMContentLoaded', function () {
  loadLikes();
  app.index = getNextIndex();

  var player = safeGet('player');
  if (player) player.src = setURL();

  updateLikeButtonUI();

  /* Recommended playlists */
  var recommendedPlaylists = [
    { id:"PL_QVa43XFPh3sUAGAz_H-w9WrydCz67mz", title:"Playlist 1" },
    { id:"PL_QVa43XFPh2ZsFeeqPm2suYQPfGAjhRF", title:"Playlist 2" },
    { id:"PLgzTt0k8mXzEk586ze4BjvDXR7c-TUSnx", title:"Playlist 3" },
    { id:"PLI_7Mg2Z_-4Lfo7Eo2jxrFAWR5KbBBjWP", title:"Playlist 4" },
    { id:"PL4_6pva_T8ptMSVkBppV5KDPZJw1xaJEj", title:"Playlist 5" },
    { id:"PLrcF4sMJ9163awliLeWPfb4js1Qba1Iwf", title:"Playlist 6" },
    { id:"PLt1KecuO3RM3HjHWHVRxCjdqQDP9I7L2i", title:"Playlist 7" },
    { id:"PLfEYZTAqw718tL9bdcwpuE7ivw7B7FMCO", title:"Playlist 8" }
  ];

  var thumb = 'https://randomclickers.com/music/static/images/playlist.jpg';
  var container = safeGet('recommendedContainer');
  if (container && !container.dataset.built) {
    container.dataset.built = '1';
    var fragment = document.createDocumentFragment();
    recommendedPlaylists.forEach(function(pl) {
      var d = document.createElement('div');
      d.className = 'rec-item';
      d.dataset.plid = pl.id;
      d.innerHTML = '<img class="rec-thumb" src="'+thumb+'" alt="thumb" loading="lazy">' +
                    '<div class="rec-title">' + pl.title + '</div>';
      fragment.appendChild(d);
    });
    container.appendChild(fragment);
    container.appendChild(container.cloneNode(true));
  }

  /* Delegation click */
  if (container) {
    container.addEventListener('click', function (e) {
      var node = e.target;
      while(node && !node.classList.contains('rec-item')) node = node.parentElement;
      if (!node) return;
      var plid = node.dataset.plid;
      if (!plid) return;
      app.playlist.id = plid;
      app.index = 1;
      var newSrc = setURL();
      if (!iframeHas(app.playlist.id, app.index)) {
        if (player) player.src = newSrc;
      }
      updateLikeButtonUI();
    }, { passive: true });
  }

  /* Like button */
  var likeBtn = safeGet('likeButton');
  if (likeBtn) {
    likeBtn.addEventListener('click', function () {
      if (app.likes[app.index]) delete app.likes[app.index];
      else app.likes[app.index] = 1;
      saveLikes();
      updateLikeButtonUI();
    }, { passive: true });
  }

  /* Refresh button */
  var refreshBtn = safeGet('refreshButton');
  if (refreshBtn) {
    refreshBtn.addEventListener('click', function () {
      app.index = getNextIndex();
      var newSrc = setURL();
      if (!iframeHas(app.playlist.id, app.index) && player) player.src = newSrc;
      updateLikeButtonUI();
    }, { passive: true });
  }

  /* Smart mode */
  var smartToggle = safeGet('smartModeToggle'), smartActive = false;
  function smartMouseDown(e) {
    if (!smartToggle || !smartToggle.checked) return;
    if (player && player.contains(e.target)) return;
    if (e.button === 0) { e.preventDefault(); app.index = getNextIndex(); if(player) player.src=setURL(); updateLikeButtonUI();}
    else if (e.button === 2) { e.preventDefault(); if(likeBtn) likeBtn.click(); }
  }
  function smartContext(e) { if(!smartToggle||!smartToggle.checked) return; e.preventDefault(); }
  function enableSmart() { if(smartActive) return; document.addEventListener('mousedown', smartMouseDown); document.addEventListener('contextmenu', smartContext); smartActive=true; document.body.classList.add('smart-mode'); }
  function disableSmart() { if(!smartActive) return; document.removeEventListener('mousedown', smartMouseDown); document.removeEventListener('contextmenu', smartContext); smartActive=false; document.body.classList.remove('smart-mode'); }

  try {
    var saved = localStorage.getItem('smartBoxMode');
    if (saved===null) { localStorage.setItem('smartBoxMode','enabled'); saved='enabled'; }
    if (smartToggle) {
      smartToggle.checked = (saved==='enabled');
      if (smartToggle.checked) enableSmart(); else disableSmart();
      smartToggle.addEventListener('change', function() { localStorage.setItem('smartBoxMode', smartToggle.checked?'enabled':'disabled'); if(smartToggle.checked) enableSmart(); else disableSmart(); }, {passive:true});
    } else disableSmart();
  } catch(e){ disableSmart(); }

  var preloader = safeGet('preloader'); if(preloader) setTimeout(()=>{preloader.style.display='none';},400);
  updateLikeButtonUI();

});
