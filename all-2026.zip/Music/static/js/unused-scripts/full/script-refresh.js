document.addEventListener("DOMContentLoaded", function () {
            const touchBox = document.getElementById("touchBox");

            let touchCount = 0; // شمارنده برای تعداد لمس‌ها
            let startX, startY; // مکان شروع لمس
            const minSwipeDistance = 30; // حداقل فاصله حرکت برای مالش (در پیکسل)

            // Function to detect rapid touches/swipes in the box
            const detectSwipe = (startX, startY, endX, endY) => {
                const distance = Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
                return distance >= minSwipeDistance;
            };

            // Function to increment the touch count and reload after 5 touches
            const detectRapidTouches = () => {
                touchCount++;
                if (touchCount >= 5) {
                    location.reload(true); // Reload the page after 5 swipes/touches
                }
            };

            // Prevent click event
            touchBox.addEventListener("click", function (e) {
                e.preventDefault(); // جلوگیری از کلیک
            });

            // Touch start event
            touchBox.addEventListener("touchstart", function (e) {
                e.preventDefault(); // جلوگیری از تعاملات پیش‌فرض
                const touch = e.changedTouches[0];
                startX = touch.pageX;
                startY = touch.pageY; // ثبت مکان شروع لمس
            });

            // Touch move event (detect the swipe/movement)
            touchBox.addEventListener("touchmove", function (e) {
                e.preventDefault(); // جلوگیری از تعاملات پیش‌فرض
                const touch = e.changedTouches[0];
                const endX = touch.pageX;
                const endY = touch.pageY;

                // اگر لمس یا مالش به اندازه کافی بزرگ بود، شمارش را افزایش دهیم
                if (detectSwipe(startX, startY, endX, endY)) {
                    detectRapidTouches(); // افزایش شمارش لمس
                    startX = endX; // مکان جدید شروع
                    startY = endY;
                }
            });
        });