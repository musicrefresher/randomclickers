  	const YOUTUBE_PLAYLIST_ID = "PLt1KecuO3RM3HjHWHVRxCjdqQDP9I7L2i&si=DWZACY0FDOqRMpci"; // Your Playlist ID
        const YOUTUBE_ORIGIN = "https://randomclickers.com"; // Your Website Domain

        function openYouTubeSession() {
            // Check if YouTube session has already been opened (use localStorage)
            if (!localStorage.getItem("youtubeOpened")) {
                let youtubeTab = window.open("https://www.youtube.com/", "_blank");

                // Wait for 3 seconds, then close the tab and load the iframe
                setTimeout(() => {
                    if (youtubeTab) {
                        youtubeTab.close();
                    }

                    // Set the flag in localStorage to prevent reopening YouTube
                    localStorage.setItem("youtubeOpened", "true");

                    // Load the YouTube playlist after confirming session
                    document.getElementById("player").src = 
                        `https://www.youtube.com/embed/videoseries?list=${YOUTUBE_PLAYLIST_ID}&autoplay=1&mute=1&enablejsapi=1&origin=${YOUTUBE_ORIGIN}`;
                }, 3000); // Adjust delay if needed
            } else {
                // If YouTube session has already been opened, just load the playlist
                document.getElementById("player").src = 
                    `https://www.youtube.com/embed/videoseries?list=${YOUTUBE_PLAYLIST_ID}&autoplay=1&mute=1&enablejsapi=1&origin=${YOUTUBE_ORIGIN}`;
            }
        }

        // Open YouTube session when page loads
        window.onload = openYouTubeSession;