
const CLIENT_ID = "970567680710-tup9q0dqn5kkf5hk72ehkqbom73dsksa.apps.googleusercontent.com";
const API_KEY = "AIzaSyDbyXlxvwnazhi3nxnwdm0t2YhzcKwKHHA";
const SCOPES = "https://www.googleapis.com/auth/youtube.readonly";

let tokenClient;
let accessToken;

// Load Google API
function gapiLoad() {
    gapi.load("client", initializeGapiClient);
}

async function initializeGapiClient() {
    await gapi.client.init({
        apiKey: API_KEY,
        discoveryDocs: ["https://www.googleapis.com/discovery/v1/apis/youtube/v3/rest"],
    });
}

window.onload = () => {
    gapiLoad();

    tokenClient = google.accounts.oauth2.initTokenClient({
        client_id: CLIENT_ID,
        scope: SCOPES,
        callback: (tokenResponse) => {
            accessToken = tokenResponse.access_token;
            loadUserPlaylists();
        },
    });

    document.getElementById("googleLogin").onclick = () => {
        tokenClient.requestAccessToken();
    };
};

// Load User Playlists
function loadUserPlaylists() {
    gapi.client.youtube.playlists.list({
        part: "snippet,contentDetails",
        mine: true,
        maxResults: 20
    }).then(response => {
        const items = response.result.items;
        const container = document.getElementById("userPlaylists");

        container.innerHTML = "<h3 style='color:white'>Your Playlists</h3>";

        items.forEach(pl => {
            const title = pl.snippet.title;
            const id = pl.id;
            const thumb = pl.snippet.thumbnails.medium.url;

            const div = document.createElement("div");
            div.className = "playlist-card";
            div.style.marginTop = "10px";

            div.innerHTML = `
                <img src="${thumb}" width="120" height="90">
                <span style="margin-left:10px">${title}</span>
            `;

            div.onclick = () => {
                document.getElementById("player").src =
                    `https://www.youtube.com/embed?listType=playlist&list=${id}&autoplay=1`;
            };

            container.appendChild(div);
        });
    });
}

