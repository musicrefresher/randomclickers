document.addEventListener("DOMContentLoaded", function () {

    // --- SAFE GET FUNCTION ---
    const $ = (id) => document.getElementById(id);

    // --- PRELOADER ---
    const preloader = $("preloader");
    if (preloader) {
        setTimeout(() => {
            preloader.style.display = "none";
        }, 500);
    }

    // --- REFRESH BUTTON ---
    const refreshBtn = $("refreshBtn");

    // اگر نبود، اصلاً لیسنر اضافه نکن
    if (refreshBtn) {

        // کلیک روی کل صفحه
        document.addEventListener("click", function (e) {
            if (!refreshBtn.classList.contains("visible") && e.target.id !== "refreshBtn") {
                refreshBtn.classList.add("visible");
            }
        });

        // خود دکمه
        refreshBtn.addEventListener("click", function (e) {
            e.stopPropagation(); // جلوگیری از فعال‌شدن رویداد کلیک صفحه
            location.reload(true);
        });
    }

});
