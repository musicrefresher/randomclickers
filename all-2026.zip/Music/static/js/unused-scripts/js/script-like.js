
    var app = {
        playlist: {
            id: 'PLt1KecuO3RM3HjHWHVRxCjdqQDP9I7L2i',
            max: 155,
        },
        index: null,
        likes: {},
        baseURL: 'https://www.youtube.com/embed/?list={0}&index={1}',
        queryStrings: '&t=15&wmode=transparent&autoplay=1&rel=0&showinfo=0&iv_load_policy=3&showsearch=0&autohide=1&controls=0',
        iframeSrc: '',
    };

    // ذخیره لایک‌ها در Local Storage
    var saveLikes = function() {
        localStorage.setItem('videoLikes', JSON.stringify(app.likes));
    };

    // بازیابی لایک‌ها از Local Storage
    var loadLikes = function() {
        var savedLikes = localStorage.getItem('videoLikes');
        if (savedLikes) {
            app.likes = JSON.parse(savedLikes);
        }
    };

    var generateRandom = function(num) {
        return Math.floor(Math.random() * num);
    };

    var getNextIndex = function() {
        var weightedList = [];
        for (var i = 0; i < app.playlist.max; i++) {
            var weight = app.likes[i] ? 5 : 1;  // Increase weight to 5 for liked videos
            for (var j = 0; j < weight; j++) {
                weightedList.push(i);
            }
        }
        return weightedList[generateRandom(weightedList.length)];
    };

    String.prototype.format = function() {
        var string = this;
        for (var i = 0; i < arguments.length; i++) {
            var regexp = new RegExp('\\{' + i + '\\}', 'gi');
            string = string.replace(regexp, arguments[i]);
        }
        return string;
    };

    var setURL = function() {
        return app.baseURL.format(app.playlist.id, app.index) + app.queryStrings;
    };

    // Initialize
    loadLikes();  // بازیابی لایک‌ها از Local Storage
    app.index = getNextIndex();
    app.iframeSrc = setURL();

    $(function() {
        $('#player').attr('src', app.iframeSrc);

        // اگر لایک شده باشد
        if (app.likes[app.index]) {
            $('#likeButton').addClass('liked');
            $('#likeButtonText').text("Liked");
        }

        // کلیک روی دکمه لایک
        $('#likeButton').click(function(event) {
            const buttonText = document.getElementById("likeButtonText").innerText;

            // اگر متن دکمه "Like" باشد
            if (buttonText === "Like") {
                // ذخیره لایک در LocalStorage
                if (!app.likes[app.index]) {
                    app.likes[app.index] = 1;
                    saveLikes();  // ذخیره لایک‌ها در Local Storage
                    $(this).fadeTo(200, 0.5);  // Fade the button to half opacity after liking
                }

                // تغییر آیکن لایک به حالت پر
                const likeIcon = document.getElementById("likeIcon");
                likeIcon.innerHTML = '&#xf164;'; // آیکن لایک پر
                likeIcon.style.color = 'green'; // رنگ سبز برای نشان دادن لایک

                // تغییر متن دکمه به "Liked"
                document.getElementById("likeButtonText").innerText = "Liked";
                $('#likeButton').addClass('liked');
            }
        });

        // کلیک روی دکمه رفرش
        $('#refreshButton').click(function() {
            location.reload();  // رفرش صفحه
        });
    });
