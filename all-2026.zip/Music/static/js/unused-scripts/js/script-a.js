
        // Wait for the DOM to be fully loaded before adding event listeners
        document.addEventListener("DOMContentLoaded", function () {
            // Hide preloader after the page fully loads
            setTimeout(() => {
                document.getElementById("preloader").style.display = "none";
            }, 500); // Small delay for smooth transition

            // Show the refresh button when clicking anywhere on the page (except the button itself)
            document.addEventListener("click", function (e) {
                const refreshBtn = document.getElementById("refreshBtn");

                // Only show the refresh button if it's not visible and clicked outside the button
                if (!refreshBtn.classList.contains("visible") && e.target.id !== "refreshBtn") {
                    refreshBtn.classList.add("visible");
                }
            });

            // Ensure the refresh button works correctly
            document.getElementById("refreshBtn").addEventListener("click", function () {
                location.reload(true); // Force reload the page
            });
        });
 

    