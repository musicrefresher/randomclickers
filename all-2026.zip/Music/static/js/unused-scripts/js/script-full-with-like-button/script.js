var app = {
    playlist: {
        id: 'PLt1KecuO3RM3HjHWHVRxCjdqQDP9I7L2i&si=DWZACY0FDOqRMpci',
        max: 50, // Replace with the total number of videos in the playlist
    },
    index: null,
    playedIndices: [], // To track which videos have been played
    baseURL: 'https://www.youtube.com/embed/?list={0}&index={1}',
    queryStrings: '&amp;t=15&amp;wmode=transparent&amp;autoplay=1&amp;rel=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;autohide=1&amp;controls=0&amp;wadsworth=1',
    iframeSrc: '',
};

var generateRandom = function(num) {
    return Math.floor(Math.random() * num);
};

var getNextIndex = function() {
    // Get a list of unplayed indices
    var unplayedIndices = Array.from({ length: app.playlist.max }, (_, i) => i).filter(
        (index) => !app.playedIndices.includes(index)
    );

    // If all videos have been played, reset the playedIndices list
    if (unplayedIndices.length === 0) {
        app.playedIndices = [];
        unplayedIndices = Array.from({ length: app.playlist.max }, (_, i) => i);
    }

    // Pick a random index from the unplayed indices
    var randomIndex = generateRandom(unplayedIndices.length);
    var nextIndex = unplayedIndices[randomIndex];

    // Add the selected index to the playedIndices list
    app.playedIndices.push(nextIndex);
    return nextIndex;
};

var setURL = function() {
    return app.baseURL.format(app.playlist.id, app.index) + app.queryStrings;
};

String.prototype.format = function() {
    var string = this;
    for (var i = 0; i < arguments.length; i++) {
        var regexp = new RegExp('\\{' + i + '\\}', 'gi');
        string = string.replace(regexp, arguments[i]);
    }
    return string;
};

// Initialize the first video
app.index = getNextIndex();
app.iframeSrc = setURL();

$(function () {
    $('#player').attr('src', app.iframeSrc);

    $('#back').click(function() {
        if (app.index > 0) {
            app.index--;
        } else {
            app.index = app.playlist.max - 1; // Loop to the last item
        }
        app.iframeSrc = setURL();
        $('#player').attr('src', app.iframeSrc);
    });

    $('#forward').click(function() {
        app.index = getNextIndex();
        app.iframeSrc = setURL();
        $('#player').attr('src', app.iframeSrc);
    });
});
