var app = {
    apiKey: 'AIzaSyDbyXlxvwnazhi3nxnwdm0t2YhzcKwKHHA',  // Replace with your actual YouTube API key
    playlist: {
        id: 'PLt1KecuO3RM3HjHWHVRxCjdqQDP9I7L2i&si=DWZACY0FDOqRMpci', // Your YouTube playlist ID
        videos: [],  // Array to store video IDs
    },
    index: null,
    likes: {},
    baseURL: 'https://www.youtube.com/embed/{0}?autoplay=1&rel=0&showinfo=0&iv_load_policy=3&controls=1',
    iframeSrc: '',
};

// ذخیره لایک‌ها در Local Storage
var saveLikes = function() {
    localStorage.setItem('videoLikes', JSON.stringify(app.likes));
};

// بازیابی لایک‌ها از Local Storage
var loadLikes = function() {
    var savedLikes = localStorage.getItem('videoLikes');
    if (savedLikes) {
        app.likes = JSON.parse(savedLikes);
    }
};

var generateRandom = function(num) {
    return Math.floor(Math.random() * num);
};

var getNextIndex = function() {
    var weightedList = [];
    for (var i = 0; i < app.playlist.videos.length; i++) {
        var weight = app.likes[i] ? 5 : 1;  // Increase weight for liked videos
        for (var j = 0; j < weight; j++) {
            weightedList.push(i);
        }
    }
    return weightedList[generateRandom(weightedList.length)];
};

String.prototype.format = function() {
    var string = this;
    for (var i = 0; i < arguments.length; i++) {
        var regexp = new RegExp('\\{' + i + '\\}', 'gi');
        string = string.replace(regexp, arguments[i]);
    }
    return string;
};

var setURL = function(videoId) {
    return app.baseURL.format(videoId);
};

// Fetch playlist videos from YouTube Data API
var fetchPlaylistVideos = function() {
    var apiUrl = `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=${app.playlist.id}&maxResults=50&key=${app.apiKey}`;

    return fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            app.playlist.videos = data.items.map(item => item.snippet.resourceId.videoId);
            app.index = getNextIndex();
            app.iframeSrc = setURL(app.playlist.videos[app.index]);
            $('#player').attr('src', app.iframeSrc);
        })
        .catch(error => console.error('Error fetching YouTube playlist:', error));
};

// Initialize
$(function() {
    loadLikes();  // Load likes from Local Storage

    fetchPlaylistVideos().then(() => {
        // Set the initial iframe source
        $('#player').attr('src', app.iframeSrc);

        // Fade out the like button if already liked
        if (app.likes[app.index]) {
            $('#likeButton').fadeTo(0, 0.5);
        }

        $('#back').click(function() {
            app.index = app.index > 0 ? app.index - 1 : app.playlist.videos.length - 1;
            app.iframeSrc = setURL(app.playlist.videos[app.index]);
            $('#player').attr('src', app.iframeSrc);

            // Adjust the like button opacity based on previous likes
            if (app.likes[app.index]) {
                $('#likeButton').fadeTo(200, 0.5);
            } else {
                $('#likeButton').fadeTo(200, 1);
            }
        });

        $('#forward').click(function() {
            app.index = getNextIndex();
            app.iframeSrc = setURL(app.playlist.videos[app.index]);
            $('#player').attr('src', app.iframeSrc);

            // Adjust the like button opacity based on previous likes
            if (app.likes[app.index]) {
                $('#likeButton').fadeTo(200, 0.5);
            } else {
                $('#likeButton').fadeTo(200, 1);
            }
        });

        $('#likeButton').click(function() {
            if (!app.likes[app.index]) {
                app.likes[app.index] = 1;
                saveLikes();  // Save likes to Local Storage
                $(this).fadeTo(200, 0.5);  // Fade the button to half opacity after liking
            }
        });

        // Error handling for iframe
        $('#player').on('error', function() {
            alert('There was an issue loading the video. Trying another one...');
            app.index = getNextIndex();
            app.iframeSrc = setURL(app.playlist.videos[app.index]);
            $('#player').attr('src', app.iframeSrc);
        });
    });
});















var app = {
  apiKey: '',  // API key will be added via prompt
  playlist: {
    id: '',  // Playlist ID will be added via prompt
    videos: [],
  },
  index: null,
  likes: {},
  baseURL: 'https://www.youtube.com/embed/{0}?autoplay=1&rel=0&showinfo=0&iv_load_policy=3&controls=1',
  iframeSrc: '',
};

// Prompt user for API key and playlist ID
app.apiKey = prompt("AIzaSyDbyXlxvwnazhi3nxnwdm0t2YhzcKwKHHA");
app.playlist.id = prompt("PLt1KecuO3RM3HjHWHVRxCjdqQDP9I7L2i");

var saveLikes = function() {
  localStorage.setItem('videoLikes', JSON.stringify(app.likes));
};

var loadLikes = function() {
  var savedLikes = localStorage.getItem('videoLikes');
  if (savedLikes) {
    app.likes = JSON.parse(savedLikes);
  }
};

var generateRandom = function(num) {
  return Math.floor(Math.random() * num);
};

var getNextIndex = function() {
  var weightedList = [];
  for (var i = 0; i < app.playlist.videos.length; i++) {
    var weight = app.likes[app.playlist.videos[i]] ? 5 : 1;
    for (var j = 0; j < weight; j++) {
      weightedList.push(i);
    }
  }
  return weightedList.length > 0 ? weightedList[generateRandom(weightedList.length)] : 0;
};

String.prototype.format = function() {
  var string = this;
  for (var i = 0; i < arguments.length; i++) {
    var regexp = new RegExp('\\{' + i + '\\}', 'gi');
    string = string.replace(regexp, arguments[i]);
  }
  return string;
};

var setURL = function(videoId) {
  return app.baseURL.format(videoId);
};

var fetchPlaylistVideos = function() {
  var apiUrl = `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=${app.playlist.id}&maxResults=50&key=${app.apiKey}`;
  
  return fetch(apiUrl)
    .then(response => response.json())
    .then(data => {
      app.playlist.videos = data.items
        .filter(item => item.snippet && item.snippet.resourceId)
        .map(item => item.snippet.resourceId.videoId);
      
      if (app.playlist.videos.length > 0) {
        app.index = getNextIndex();
        app.iframeSrc = setURL(app.playlist.videos[app.index]);
        document.getElementById('player').src = app.iframeSrc;
      } else {
        alert('No valid videos found in the playlist.');
      }
    })
    .catch(error => console.error('Error fetching YouTube playlist:', error));
};

document.addEventListener('DOMContentLoaded', function() {
  loadLikes();
  fetchPlaylistVideos().then(() => {
    document.getElementById('player').src = app.iframeSrc;

    if (app.likes[app.playlist.videos[app.index]]) {
      document.getElementById('likeButton').style.opacity = 0.5;
    }

    document.getElementById('back').addEventListener('click', function() {
      app.index = app.index > 0 ? app.index - 1 : app.playlist.videos.length - 1;
      app.iframeSrc = setURL(app.playlist.videos[app.index]);
      document.getElementById('player').src = app.iframeSrc;

      document.getElementById('likeButton').style.opacity = app.likes[app.playlist.videos[app.index]] ? 0.5 : 1;
    });

    document.getElementById('forward').addEventListener('click', function() {
      app.index = getNextIndex();
      app.iframeSrc = setURL(app.playlist.videos[app.index]);
      document.getElementById('player').src = app.iframeSrc;

      document.getElementById('likeButton').style.opacity = app.likes[app.playlist.videos[app.index]] ? 0.5 : 1;
    });

    document.getElementById('likeButton').addEventListener('click', function() {
      var currentVideoId = app.playlist.videos[app.index];
      if (!app.likes[currentVideoId]) {
        app.likes[currentVideoId] = 1;
        saveLikes();
        this.style.opacity = 0.5;
      }
    });
  });
});
