var auth2;

    function startApp() {
      gapi.load('auth2', function() {
        auth2 = gapi.auth2.init({
          client_id: '970567680710-tup9q0dqn5kkf5hk72ehkqbom73dsksa.apps.googleusercontent.com',
          scope: 'https://www.googleapis.com/auth/youtube.readonly',
          ux_mode: 'redirect',
          redirect_uri: 'https://music-refresher.com/oauth2callback'
        });

        document.getElementById('loginButton').addEventListener('click', function() {
          if (!auth2) {
            console.error('auth2 not initialized');
            document.getElementById('status').innerHTML = `<p>Error: auth2 not initialized</p>`;
            return;
          }

          auth2.signIn().then(function(user) {
            console.log('User signed in:', user.getBasicProfile());
          }).catch(function(error) {
            console.error('Sign-in error:', error);
            document.getElementById('status').innerHTML = `<p>Error: ${error.error}</p>`;
          });
        });
      });
    }

    startApp();