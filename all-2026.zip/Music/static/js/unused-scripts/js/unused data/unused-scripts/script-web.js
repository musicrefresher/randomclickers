var app = {
    playlist: {},
    index: null,
    baseURL: 'https://www.youtube.com/embed/?list={0}&index={1}',
    queryStrings: '&amp;t=15&amp;wmode=transparent&amp;autoplay=1&amp;rel=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;autohide=1&amp;controls=0&amp;wadsworth=1',
    iframeSrc: '',
};

var generateRandom = function(num) {
    return Math.floor(Math.random() * num);
};

var setURL = function() {
    return app.baseURL.format(app.playlist.id, app.index) + app.queryStrings;
};

String.prototype.format = function() {
    var string = this;
    for (var i = 0; i < arguments.length; i++) {
        var regexp = new RegExp('\\{' + i + '\\}', 'gi');
        string = string.replace(regexp, arguments[i]);
    }
    return string;
};

// Persist playlist selection in localStorage
app.playlist = (function() {
    // Check if a playlist is already saved in localStorage
    var storedPlaylist = localStorage.getItem('selectedPlaylist');
    if (storedPlaylist) {
        console.log('Loaded playlist from storage.');
        return JSON.parse(storedPlaylist);
    }

    // Select a random playlist if not found in storage
    var loc = generateRandom(playlists.length);
    var selectedPlaylist = playlists[loc];
    localStorage.setItem('selectedPlaylist', JSON.stringify(selectedPlaylist));
    console.log('Randomly selected a new playlist:', selectedPlaylist);
    return selectedPlaylist;
}());

// Set the index (can be reset to 0 if necessary)
app.index = generateRandom(app.playlist.max);
console.log('Starting index:', app.index);

app.iframeSrc = setURL();
console.log('Initial iframe source:', app.iframeSrc);

$(function () {
    $('#player').attr('src', app.iframeSrc);

    $('#back').click(function() {
        if (app.index > 0) {
            app.index--;
        } else {
            app.index = app.playlist.max - 1; // Loop to the last item
        }
        app.iframeSrc = setURL();
        console.log('Back clicked. New index:', app.index, 'New URL:', app.iframeSrc);
        $('#player').attr('src', app.iframeSrc);
    });

    $('#forward').click(function() {
        if (app.index < app.playlist.max - 1) {
            app.index++;
        } else {
            app.index = 0; // Loop back to the first item
        }
        app.iframeSrc = setURL();
        console.log('Forward clicked. New index:', app.index, 'New URL:', app.iframeSrc);
        $('#player').attr('src', app.iframeSrc);
    });
});
