<?php
// Set header for JSON response
header('Content-Type: application/json');

// === MySQL connection setup ===
$host = "localhost";        // Change if needed
$user = "root";             // Change to your MySQL username
$pass = "";                 // Change to your MySQL password
$dbname = "active"; // Your database name

// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    echo json_encode(['error' => 'Database connection failed']);
    exit();
}

// Get visitor IP address
$ip = $_SERVER['REMOTE_ADDR'];

// Remove old visitors (inactive for more than 60 seconds)
$conn->query("DELETE FROM active_visitors WHERE last_active < NOW() - INTERVAL 60 SECOND");

// Check if the visitor IP already exists
$stmt = $conn->prepare("SELECT id FROM active_visitors WHERE ip_address = ?");
$stmt->bind_param("s", $ip);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows === 0) {
    // Insert new visitor
    $insert = $conn->prepare("INSERT INTO active_visitors (ip_address) VALUES (?)");
    $insert->bind_param("s", $ip);
    $insert->execute();
    $insert->close();
} else {
    // Update existing visitor's last active time
    $update = $conn->prepare("UPDATE active_visitors SET last_active = NOW() WHERE ip_address = ?");
    $update->bind_param("s", $ip);
    $update->execute();
    $update->close();
}

$stmt->close();

// Get total active visitors
$result = $conn->query("SELECT COUNT(*) AS total FROM active_visitors");
$row = $result->fetch_assoc();
$activeCount = (int)$row['total'];

// Output JSON response
echo json_encode(['active' => $activeCount]);

// Close connection
$conn->close();
?>
