document.addEventListener("DOMContentLoaded", function () {
    // Hide preloader after the page fully loads
    setTimeout(() => {
        const preloader = document.getElementById("preloader");
        if (preloader) preloader.style.display = "none";
    }, 500); // Small delay for smooth transition

    // Refresh button functionality
    const refreshBtn = document.getElementById("refreshBtn");
    if (refreshBtn) {
        document.addEventListener("click", function (e) {
            if (!refreshBtn.classList.contains("visible") && e.target.id !== "refreshBtn") {
                refreshBtn.classList.add("visible");
            }
        });
        refreshBtn.addEventListener("click", function () {
            location.reload(true); // Force reload the page
        });
    }

    // Initialize app
    const app = {
        playlist: {
            id: 'PLt1KecuO3RM0ONHI6DDFiixvN-ZBrm8AP',
            max: 200,
        },
        index: null,
        likes: {},
        baseURL: 'https://www.youtube.com/embed/?list={0}&index={1}',
        queryStrings: '&enablejsapi=1&wmode=transparent&autoplay=0&rel=0&showinfo=0&iv_load_policy=3&showsearch=0&autohide=1&controls=0',
    };

    // Save and load likes from Local Storage
    function saveLikes() {
        localStorage.setItem('videoLikes', JSON.stringify(app.likes));
    }

    function loadLikes() {
        const savedLikes = localStorage.getItem('videoLikes');
        if (savedLikes) {
            app.likes = JSON.parse(savedLikes);
        }
    }

    // Get next index based on likes
    function getNextIndex() {
        const weightedList = [];
        for (let i = 0; i < app.playlist.max; i++) {
            const weight = app.likes[i] ? 5 : 1;
            for (let j = 0; j < weight; j++) {
                weightedList.push(i);
            }
        }
        return weightedList[Math.floor(Math.random() * weightedList.length)];
    }

    // Initialize app state
    loadLikes();
    app.index = getNextIndex();

    // Update player and like button
    function updatePlayer() {
        location.reload(true); // Force reload the page
    }

    // Like button functionality
    const likeButton = document.getElementById("likeButton");
    if (likeButton) {
        likeButton.addEventListener("click", function () {
            const buttonText = likeButton.querySelector("#likeButtonText").textContent;
            if (buttonText === "Like") {
                app.likes[app.index] = 1;
                saveLikes();
                likeButton.classList.add("liked");
                likeButton.querySelector("#likeButtonText").textContent = "Liked";
                likeButton.querySelector("#likeIcon").innerHTML = '&#xf164;';
                likeButton.querySelector("#likeIcon").style.color = 'green';
            }
        });
    }

    // Refresh button functionality for player
    const refreshButton = document.getElementById("refreshButton");
    if (refreshButton) {
        refreshButton.addEventListener("click", function () {
            app.index = getNextIndex();
            updatePlayer(); // Reload the page to play new music
        });
    }

    // Smart mode functionality
    const smartToggle = document.getElementById("smartModeToggle");
    if (smartToggle) {
        function activateSmartMode() {
            document.addEventListener("mousedown", onDocumentMouseDown);
            document.addEventListener("contextmenu", onDocumentContextMenu);
            document.body.classList.add("smart-mode");
        }

        function deactivateSmartMode() {
            document.removeEventListener("mousedown", onDocumentMouseDown);
            document.removeEventListener("contextmenu", onDocumentContextMenu);
            document.body.classList.remove("smart-mode");
        }

        function onDocumentMouseDown(e) {
            if (!smartToggle.checked) return;
            if (playerIframe && playerIframe.contains(e.target)) return;
            e.preventDefault();
            if (e.button === 0) {
                window.location.reload(); // Left click: Refresh page
            } else if (e.button === 2) {
                likeButton.click(); // Right click: Like button
            }
        }

        function onDocumentContextMenu(e) {
            if (!smartToggle.checked) return;
            e.preventDefault();
        }

        // Load and save smart mode state
        window.addEventListener("DOMContentLoaded", () => {
            let savedMode = localStorage.getItem("smartBoxMode");
            if (savedMode === null) {
                savedMode = "enabled";
                localStorage.setItem("smartBoxMode", savedMode);
            }
            smartToggle.checked = (savedMode === "enabled");
            if (smartToggle.checked) {
                activateSmartMode();
            } else {
                deactivateSmartMode();
            }
        });

        // Toggle smart mode
        smartToggle.addEventListener("change", () => {
            if (smartToggle.checked) {
                localStorage.setItem("smartBoxMode", "enabled");
                activateSmartMode();
            } else {
                localStorage.setItem("smartBoxMode", "disabled");
                deactivateSmartMode();
            }
        });
    }

    // Initial player update
    updatePlayer();
});