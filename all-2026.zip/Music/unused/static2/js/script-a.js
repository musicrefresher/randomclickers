document.addEventListener("DOMContentLoaded", function () {

    // --- PRELOADER ---
    const preloader = document.getElementById("preloader");
    if (preloader) {
        setTimeout(() => {
            preloader.style.display = "none";
        }, 500);
    }

    // --- REFRESH BUTTON ---
    const refreshBtn = document.getElementById("refreshButton");
    if (refreshBtn) {

        // نمایش دکمه هنگام کلیک روی صفحه
        document.addEventListener("click", function (e) {
            if (
                !refreshBtn.classList.contains("visible") &&
                e.target.id !== "refreshButton"
            ) {
                refreshBtn.classList.add("visible");
            }
        });

        // رفرش کردن صفحه
        refreshBtn.addEventListener("click", function () {
            location.reload(true);
        });
    }

});
