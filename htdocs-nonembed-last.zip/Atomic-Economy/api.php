<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$input = json_decode(file_get_contents("php://input"), true);
$mass = floatval($input['mass'] ?? 0);
$description = trim($input['description'] ?? '');

if ($mass <= 0 || empty($description)) {
    echo json_encode(['error' => 'ورودی نامعتبر']);
    exit;
}

$API_KEY = 'sk-d94ec4d80f5f41ab8cb3c8c27b7c7e00';

/**
 * سیستم پرامپت واقع‌بینانه برای قیمت‌گذاری
 */
$system_prompt = <<<EOT
شما یک کارشناس قیمت‌گذاری کالا در ایران هستید. بر اساس توضیحات کالا و جرم آن، سطح (Level) بین 0 تا 100 تعیین کنید.

## منطق قیمت‌گذاری واقعی:
1. **ارزش اصلی در برند و تکنولوژی است، نه جرم!**
2. یک گوشی آیفون 200 گرمی = 100 میلیون تومان
3. یک کیلوگرم برنج = 200 هزار تومان
4. یک ماشین 1500 کیلویی = 5 میلیارد تومان

## دسته‌بندی کالاها و سطح پیشنهادی:

### 📱 الکترونیک و تکنولوژی (ارزش بسیار بالا)
- گوشی آیفون جدید: سطح 95-100
- گوشی سامسونگ پرچمدار: سطح 90-95
- لپ‌تاپ اپل: سطح 92-98
- لپ‌تاپ گیمینگ: سطح 85-92
- کنسول بازی: سطح 80-88
- ساعت هوشمند: سطح 75-85

### 🚗 خودرو و موتورسیکلت
- خودرو لوکس جدید (مرسدس، BMW): سطح 95-100
- خودرو معمولی جدید: سطح 70-85
- موتورسیکلت: سطح 60-80

### 💎 طلا، جواهر، لوکس
- طلای 18 عیار: سطح 85-95
- جواهرات: سطح 90-98
- ساعت لوکس (رولکس): سطح 98-100
- عطر گران قیمت: سطح 70-85

### 🏠 لوازم خانگی
- یخچال ساید: سطح 65-80
- تلویزیون OLED: سطح 75-90
- ماشین لباسشویی: سطح 60-75

### 🍲 مواد غذایی
- زعفران: سطح 80-90
- گوشت قرمز ممتاز: سطح 50-65
- برنج ایرانی: سطح 40-60
- روغن زیتون: سطح 55-70
- مواد غذایی معمولی: سطح 20-50

### 👕 پوشاک
- لباس مارک معروف: سطح 60-80
- کفش ورزشی اصل: سطح 65-85
- پوشاک معمولی: سطح 30-50

### 📚 سایر
- داروهای خاص: سطح 70-90
- کتاب: سطح 20-40
- ابزار: سطح 40-70

## فاکتورهای تأثیرگذار:
1. **برند و شهرت** (مهمترین فاکتور): 40% تاثیر
2. **تکنولوژی و نوآوری**: 30% تاثیر  
3. **کیفیت ساخت**: 15% تاثیر
4. **عرضه و تقاضا**: 10% تاثیر
5. **جرم**: فقط 5% تاثیر (تنها برای کالاهای فله‌ای مهم است)

## قوانین طلایی:
1. **جرم مهم نیست**: یک الماس 1 گرمی می‌تواند سطح 100 داشته باشد
2. **برند مهم است**: اپل همیشه سطح بالا دارد
3. **تکنولوژی ارزش‌مند است**: محصولات جدید سطح بالاتر
4. **برای مواد غذایی و فله‌ای**: جرم کمی مهم‌تر است

## مثال‌های واقعی:
1. "گوشی آیفون 15 پرو مکس 1 ترابایت" - سطح: 98
   - برند اپل: +40
   - تکنولوژی بالا: +30
   - کیفیت: +20
   - کمیاب: +8
   - جرم کم (200 گرم): -0 (بی‌تأثیر)

2. "طلای 18 عیار دستبند" - سطح: 90
   - ارزش ذاتی: +35
   - خلوص: +25
   - کارmanship: +20
   - تقاضا: +10

3. "برنج ایرانی طارم ممتاز 5 کیلو" - سطح: 55
   - کیفیت: +20
   - برند ایرانی: +15
   - تقاضا: +10
   - جرم (5 کیلو): +10

4. "آب معدنی 1.5 لیتری" - سطح: 25
   - ارزش پایه: +10
   - ضرورت: +5
   - جرم (1.5 کیلو): +10

## فرمت خروجی:
{
    "level": عدد بین 0 تا 100,
    "rationale": "تحلیل کامل با ذکر امتیاز هر بخش",
    "price_suggestion": "تخمین قیمت واقعی به تومان",
    "category": "دسته‌بندی کالا"
}
EOT;

$user_message = "کالا: {$description}
جرم: {$mass} کیلوگرم

لطفاً:
1. دسته‌بندی کالا را مشخص کنید
2. سطح (0-100) را با توجه به ارزش واقعی (نه جرم) تعیین کنید
3. برای هر فاکتور امتیاز دهید
4. توضیح منطقی ارائه دهید
5. تخمین قیمت واقعی بدهید

توجه: جرم فقط برای کالاهای فله‌ای مهم است. برای کالاهای تکنولوژی و لوکس، جرم بی‌تأثیر است.";

$payload = [
    "model" => "deepseek-chat",
    "messages" => [
        ["role" => "system", "content" => $system_prompt],
        ["role" => "user", "content" => $user_message]
    ],
    "temperature" => 0.7,
    "max_tokens" => 1500,
    "response_format" => ["type" => "json_object"]
];

// ارسال به DeepSeek
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => "https://api.deepseek.com/chat/completions",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/json",
        "Authorization: Bearer " . $API_KEY
    ],
    CURLOPT_POSTFIELDS => json_encode($payload),
    CURLOPT_TIMEOUT => 60
]);

$response = curl_exec($ch);
$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if ($httpcode == 200) {
    $data = json_decode($response, true);
    $content = $data['choices'][0]['message']['content'] ?? '';
    
    // استخراج JSON
    preg_match('/\{.*\}/s', $content, $matches);
    if ($matches) {
        $result = json_decode($matches[0], true);
        
        // اعتبارسنجی
        $level = intval($result['level'] ?? 50);
        $level = max(0, min(100, $level));
        
        $result['level'] = $level;
        $result['mass'] = $mass;
        $result['description'] = $description;
        
        // محاسبه قیمت با فرمول هوشمند
        $price = calculateSmartPrice($level, $mass, $description);
        $result['calculated_price'] = $price;
        $result['formula_used'] = 'smart_exponential';
        
        echo json_encode($result);
        exit;
    }
}

// اگر AI جواب نداد، از سیستم هوشمند محلی استفاده کن
$local_result = smartLocalAnalysis($description, $mass);
echo json_encode($local_result);

/**
 * محاسبه قیمت هوشمند با فرمول نمایی
 */
function calculateSmartPrice($level, $mass, $description) {
    $FACTOR = 11707;
    
    // تشخیص نوع کالا
    $desc_lower = strtolower($description);
    
    // برای کالاهای با ارزش بالا (تکنولوژی، لوکس)
    if (preg_match('/(ایفون|آیفون|iphone|اپل|apple|ساعت هوشمند|لپ تاپ|مک بوک|گوشی پرچمدار)/', $desc_lower)) {
        // فرمول نمایی برای ارزش بالا
        // قیمت = فاکتور × 10^(سطح/25) × (جرم^0.1)
        $price = $FACTOR * pow(10, $level / 25) * pow($mass, 0.1);
    }
    // برای طلا و جواهر
    elseif (preg_match('/(طلا|سکه|جواهر|الماس|زعفران)/', $desc_lower)) {
        // قیمت = فاکتور × e^(سطح/20) × جرم
        $price = $FACTOR * exp($level / 20) * $mass;
    }
    // برای مواد غذایی
    elseif (preg_match('/(برنج|گوشت|مرغ|روغن|شکر|مواد غذایی)/', $desc_lower)) {
        // قیمت = فاکتور × سطح × جرم × 2
        $price = $FACTOR * $level * $mass * 2;
    }
    // برای خودرو
    elseif (preg_match('/(ماشین|خودرو|موتور|پراید|پژو)/', $desc_lower)) {
        // قیمت = فاکتور × سطح^2 ÷ 5
        $price = $FACTOR * pow($level, 2) / 5;
    }
    // سایر کالاها
    else {
        // فرمول عمومی: قیمت = فاکتور × e^(سطح/30) × log(جرم×1000 + 1)
        $price = $FACTOR * exp($level / 30) * log($mass * 1000 + 1);
    }
    
    // گرد کردن
    return round($price);
}

/**
 * تحلیل محلی هوشمند
 */
function smartLocalAnalysis($description, $mass) {
    $desc_lower = strtolower($description);
    $level = 50; // سطح پیش‌فرض
    
    // تشخیص دسته و سطح
    if (preg_match('/(ایفون|آیفون|iphone)/', $desc_lower)) {
        $level = 98;
        $category = "گوشی موبایل لوکس";
        $rationale = "آیفون به عنوان برند لوکس موبایل، بالاترین سطح را دارد.";
    }
    elseif (preg_match('/(اپل|apple|مک بوک)/', $desc_lower)) {
        $level = 95;
        $category = "الکترونیک لوکس";
        $rationale = "محصولات اپل به دلیل کیفیت و برند قوی سطح بسیار بالا دارند.";
    }
    elseif (preg_match('/(سامسونگ|samsung|گلکسی)/', $desc_lower)) {
        $level = 90;
        $category = "الکترونیک پرچمدار";
        $rationale = "سامسونگ برند معتبر الکترونیک با سطح بالا.";
    }
    elseif (preg_match('/(طلا|سکه)/', $desc_lower)) {
        $level = 92;
        $category = "طلا و جواهر";
        $rationale = "طلا ارزش ذاتی بالا و تقاضای زیاد دارد.";
    }
    elseif (preg_match('/(خودرو|ماشین|مرسدس|بی ام و|bmw)/', $desc_lower)) {
        $level = 85;
        $category = "خودرو";
        $rationale = "خودروهای لوکس ارزش بسیار بالایی دارند.";
    }
    elseif (preg_match('/(برنج|گوشت|مرغ)/', $desc_lower)) {
        $level = 55;
        $category = "مواد غذایی";
        $rationale = "مواد غذایی ضروری با سطح متوسط.";
    }
    elseif (preg_match('/(آب|نان|شیر)/', $desc_lower)) {
        $level = 35;
        $category = "کالاهای اساسی";
        $rationale = "کالاهای اساسی با ارزش پایین‌تر.";
    }
    else {
        $level = 60;
        $category = "سایر کالاها";
        $rationale = "کالای عمومی با سطح متوسط.";
    }
    
    // محاسبه قیمت
    $price = calculateSmartPrice($level, $mass, $description);
    
    return [
        'level' => $level,
        'rationale' => $rationale . " سطح تعیین شده: {$level}/100",
        'category' => $category,
        'calculated_price' => $price,
        'mass' => $mass,
        'description' => $description,
        'source' => 'smart_local_analysis'
    ];
}
?>