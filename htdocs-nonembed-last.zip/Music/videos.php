<?php
header("Content-Type: application/json; charset=utf-8");

if(!file_exists("videos.json")){
    echo json_encode([]);
    exit;
}

echo file_get_contents("videos.json");
?>
