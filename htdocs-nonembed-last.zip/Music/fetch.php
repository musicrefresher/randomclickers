<?php
header('Content-Type: application/json; charset=utf-8');

// جایگزین با API Key خودت
$api_key = "AIzaSyDbyXlxvwnazhi3nxnwdm0t2YhzcKwKHHA";

// پلی‌لیست از query string
$playlist_id = isset($_GET['playlist']) ? $_GET['playlist'] : "";

if(!$playlist_id){
    echo json_encode([]);
    exit;
}

$videos = [];
$pageToken = "";

do {
    $url = "https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId={$playlist_id}&maxResults=50&key={$api_key}" . ($pageToken ? "&pageToken={$pageToken}" : "");
    
    $response = file_get_contents($url);
    if(!$response){
        break;
    }

    $data = json_decode($response, true);
    if(!isset($data['items'])) break;

    foreach($data['items'] as $item){
        if(isset($item['snippet']['resourceId']['videoId'])){
            $videos[] = $item['snippet']['resourceId']['videoId'];
        }
    }

    $pageToken = isset($data['nextPageToken']) ? $data['nextPageToken'] : "";

} while($pageToken);

// ذخیره برای کش کردن
file_put_contents("videos.json", json_encode($videos, JSON_PRETTY_PRINT));

echo json_encode($videos);
?>
