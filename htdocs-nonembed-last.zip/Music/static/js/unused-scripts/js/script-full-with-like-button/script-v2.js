var app = {
    playlist: {
        id: 'PLt1KecuO3RM3HjHWHVRxCjdqQDP9I7L2i&si=DWZACY0FDOqRMpci',
        max: 100, 
    },
    index: null,
    playedIndices: [],
    likes: {}, // Object to store like counts for each index
    baseURL: 'https://www.youtube.com/embed/?list={0}&index={1}',
    queryStrings: '&amp;t=15&amp;wmode=transparent&amp;autoplay=1&amp;rel=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;autohide=1&amp;controls=0&amp;wadsworth=1',
    iframeSrc: '',
};

var generateRandom = function(num) {
    return Math.floor(Math.random() * num);
};

var getNextIndex = function() {
    var weightedList = [];
    
    for (var i = 0; i < app.playlist.max; i++) {
        var weight = app.likes[i] ? app.likes[i] + 1 : 1;
        for (var j = 0; j < weight; j++) {
            weightedList.push(i);
        }
    }

    var nextIndex = weightedList[generateRandom(weightedList.length)];
    return nextIndex;
};

var setURL = function() {
    return app.baseURL.format(app.playlist.id, app.index) + app.queryStrings;
};

String.prototype.format = function() {
    var string = this;
    for (var i = 0; i < arguments.length; i++) {
        var regexp = new RegExp('\\{' + i + '\\}', 'gi');
        string = string.replace(regexp, arguments[i]);
    }
    return string;
};

// Initialize the first video
app.index = getNextIndex();
app.iframeSrc = setURL();

$(function () {
    $('#player').attr('src', app.iframeSrc);

    $('#back').click(function() {
        if (app.index > 0) {
            app.index--;
        } else {
            app.index = app.playlist.max - 1;
        }
        app.iframeSrc = setURL();
        $('#player').attr('src', app.iframeSrc);
    });

    $('#forward').click(function() {
        app.index = getNextIndex();
        app.iframeSrc = setURL();
        $('#player').attr('src', app.iframeSrc);
    });

    // Show Like button when clicking outside the iframe
    $(document).click(function(event) {
        if (!$(event.target).closest('#player').length) {
            $('#likeButton').fadeIn();
        }
    });

    // Handle Like button click
    $('#likeButton').click(function() {
        if (!app.likes[app.index]) {
            app.likes[app.index] = 0;
        }
        app.likes[app.index]++;
        $(this).fadeOut();
    });
});
