const api_user = "108395452";     // جایگزین کن
  const api_secret = "C8NGZ4NPyt2gUDusY3AvmfGyS2iQh4VU"; // جایگزین کن

  let player;

  function checkThumbnail(videoId) {
    const thumbnailUrl = `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;

    fetch(`https://api.sightengine.com/1.0/check.json?models=nudity,wad,offensive,text-content&api_user=${api_user}&api_secret=${api_secret}&url=${encodeURIComponent(thumbnailUrl)}`)
      .then(response => response.json())
      .then(data => {
        console.log('تحلیل تصویر:', data);

        const nudityScore = data.nudity?.raw || 0;
        const weaponScore = data.weapon || 0;
        const alcoholScore = data.alcohol || 0;

        const isInappropriate = nudityScore > 0.5 || weaponScore > 0.5 || alcoholScore > 0.5;
        document.getElementById('blur-overlay').style.display = isInappropriate ? 'block' : 'none';
      })
      .catch(error => console.error('خطا در Sightengine:', error));
  }

  // YouTube IFrame API بارگذاری
  let tag = document.createElement('script');
  tag.src = "https://www.youtube.com/iframe_api";
  document.body.appendChild(tag);

  function onYouTubeIframeAPIReady() {
    player = new YT.Player('player', {
      height: '315',
      width: '560',
      playerVars: {
        listType: 'playlist',
        list: 'PLt1KecuO3RM3HjHWHVRxCjdqQDP9I7L2i&si=DWZACY0FDOqRMpci', // جایگزین کن با آیدی پلی‌لیستت
        autoplay: 1,
        controls: 1,
        modestbranding: 1
      },
      events: {
        onReady: onPlayerReady,
        onStateChange: onPlayerStateChange
      }
    });
  }

  function onPlayerReady(event) {
    event.target.playVideo();
  }

  function onPlayerStateChange(event) {
    if (event.data === YT.PlayerState.PLAYING) {
      const videoId = player.getVideoData().video_id;
      console.log("در حال پخش ویدیو:", videoId);
      checkThumbnail(videoId);
    }
  }