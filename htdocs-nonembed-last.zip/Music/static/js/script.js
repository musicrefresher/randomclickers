/* ============================
   Safe Random Player Script
   ============================ */

var app = {
  playlist: { id: 'PLt1KecuO3RM0ONHI6DDFiixvN-ZBrm8AP' },
  index: 0,
  likes: {},
  videoList: [],
  queryStrings: '?enablejsapi=1&wmode=transparent&autoplay=0&rel=0&showinfo=0&iv_load_policy=3&showsearch=0&autohide=1&controls=1'
};

function safeGet(id) { return document.getElementById(id); }

/* ========================
   LocalStorage Functions
   ======================== */

function saveLikes() { try { localStorage.setItem('videoLikes', JSON.stringify(app.likes)); } catch(e){} }
function loadLikes() { try { var s=localStorage.getItem('videoLikes'); if(s) app.likes=JSON.parse(s)||{}; } catch(e){ app.likes={}; } }
function saveVideoList() { try{ localStorage.setItem('videoList', JSON.stringify(app.videoList)); } catch(e){} }
function loadVideoList() { try{ var s=localStorage.getItem('videoList'); if(s) app.videoList=JSON.parse(s)||[]; else app.videoList=[]; } catch(e){ app.videoList=[]; } }

/* ========================
   Video URL
   ======================== */

function setURL(){
    var id = app.videoList[app.index];
    if(!id) return '';
    return "https://www.youtube.com/embed/" + id + app.queryStrings;
}

/* ========================
   Random by weight
   ======================== */

function generateRandom(num){ return Math.floor(Math.random()*num); }

function getNextIndex(){
    if(!app.videoList.length) return 0;

    var weights=[], total=0;

    for(var i=0;i<app.videoList.length;i++){
        var w = app.likes[i]?5:1;
        weights.push(w);
        total += w;
    }

    var r = generateRandom(total);

    for(var j=0;j<weights.length;j++){
        if(r<weights[j]) return j;
        r -= weights[j];
    }

    return 0;
}

/* ========================
   Fetch Playlist Videos (PHP backend)
   ======================== */

async function fetchPlaylistVideos(plid){
    try{
        const res = await fetch("fetch.php?playlist=" + plid);
        const data = await res.json();

        if(Array.isArray(data)){
            app.videoList = data;
            saveVideoList();
        }
    }catch(err){
        console.error("Playlist fetch failed:", err);
    }
}

/* ========================
   Update UI
   ======================== */

function updateLikeButtonUI(){
    var likeBtn = safeGet('likeButton'),
        likeText = safeGet('likeButtonText'),
        likeIcon = safeGet('likeIcon');

    if(!likeBtn) return;

    if(app.likes[app.index]){
        likeBtn.classList.add('liked');
        if(likeText) likeText.textContent='Liked';
        if(likeIcon){ likeIcon.innerHTML='&#xf164;'; likeIcon.style.color='green'; }
    }else{
        likeBtn.classList.remove('liked');
        if(likeText) likeText.textContent='Like';
        if(likeIcon){ likeIcon.innerHTML='&#xf087;'; likeIcon.style.color=''; }
    }
}

/* ========================
   Document Ready
   ======================== */

document.addEventListener('DOMContentLoaded', async function(){

    loadLikes();
    loadVideoList();

    var player = safeGet('player');

    if(app.videoList.length===0){
        await fetchPlaylistVideos(app.playlist.id);
    }

    app.index = getNextIndex();

    if(player) player.src = setURL();

    updateLikeButtonUI();

    /* Recommended playlists */
    var recommendedPlaylists = [
    { id:"PL_QVa43XFPh3sUAGAz_H-w9WrydCz67mz", title:"Playlist 1" },
    { id:"PL_QVa43XFPh2ZsFeeqPm2suYQPfGAjhRF", title:"Playlist 2" },
    { id:"PLgzTt0k8mXzEk586ze4BjvDXR7c-TUSnx", title:"Playlist 3" },
    { id:"PLI_7Mg2Z_-4Lfo7Eo2jxrFAWR5KbBBjWP", title:"Playlist 4" },
    { id:"PL4_6pva_T8ptMSVkBppV5KDPZJw1xaJEj", title:"Playlist 5" },
    { id:"PLrcF4sMJ9163awliLeWPfb4js1Qba1Iwf", title:"Playlist 6" },
    { id:"PLt1KecuO3RM3HjHWHVRxCjdqQDP9I7L2i", title:"Playlist 7" },
    { id:"PLfEYZTAqw718tL9bdcwpuE7ivw7B7FMCO", title:"Playlist 8" }
  ];

    var thumb = 'https://randomclickers.com/music/static/images/playlist.jpg';
    var container = safeGet('recommendedContainer');

    if(container && !container.dataset.built){
        container.dataset.built='1';
        var fragment = document.createDocumentFragment();

        recommendedPlaylists.forEach(function(pl){
            var d=document.createElement('div');
            d.className='rec-item';
            d.dataset.plid = pl.id;
            d.innerHTML='<img class="rec-thumb" src="'+thumb+'"><div class="rec-title">'+pl.title+'</div>';
            fragment.appendChild(d);
        });

        container.appendChild(fragment);
        container.appendChild(container.cloneNode(true));
    }

    /* Click on Recommended Playlist */
    if(container){
        container.addEventListener('click', async function(e){
            var node = e.target;
            while(node && !node.classList.contains('rec-item')) node=node.parentElement;
            if(!node) return;
            var plid=node.dataset.plid;
            if(!plid) return;

            app.playlist.id=plid;
            app.videoList=[];
            saveVideoList();

            await fetchPlaylistVideos(plid);

            app.index = getNextIndex();
            if(player) player.src=setURL();
            updateLikeButtonUI();
        }, {passive:true});
    }

    /* Like Button */
    var likeBtn = safeGet('likeButton');
    if(likeBtn){
        likeBtn.addEventListener('click', function(){
            if(app.likes[app.index]) delete app.likes[app.index];
            else app.likes[app.index] = 1;
            saveLikes();
            updateLikeButtonUI();
        }, {passive:true});
    }

    /* Refresh Button */
    var refreshBtn = safeGet('refreshButton');
    if(refreshBtn){
        refreshBtn.addEventListener('click', function(){
            app.index = getNextIndex();
            if(player) player.src=setURL();
            updateLikeButtonUI();
        }, {passive:true});
    }

    /* Smart Mode */
    var smartToggle = safeGet('smartModeToggle'), smartActive=false;

    function smartMouseDown(e){
        if(!smartToggle||!smartToggle.checked) return;
        if(player && player.contains(e.target)) return;
        if(e.button===0){ e.preventDefault(); app.index=getNextIndex(); if(player) player.src=setURL(); updateLikeButtonUI(); }
        else if(e.button===2){ e.preventDefault(); if(likeBtn) likeBtn.click(); }
    }

    function smartContext(e){ if(!smartToggle||!smartToggle.checked) return; e.preventDefault(); }

    function enableSmart(){ if(smartActive) return; document.addEventListener('mousedown',smartMouseDown); document.addEventListener('contextmenu',smartContext); smartActive=true; document.body.classList.add('smart-mode'); }
    function disableSmart(){ if(!smartActive) return; document.removeEventListener('mousedown',smartMouseDown); document.removeEventListener('contextmenu',smartContext); smartActive=false; document.body.classList.remove('smart-mode'); }

    try{
        var saved = localStorage.getItem('smartBoxMode');
        if(saved===null){ localStorage.setItem('smartBoxMode','enabled'); saved='enabled'; }
        if(smartToggle){ smartToggle.checked=(saved==='enabled'); if(smartToggle.checked) enableSmart(); else disableSmart();
            smartToggle.addEventListener('change', function(){ localStorage.setItem('smartBoxMode', smartToggle.checked?'enabled':'disabled'); if(smartToggle.checked) enableSmart(); else disableSmart(); }, {passive:true});
        }else disableSmart();
    }catch(e){ disableSmart(); }

    var preloader = safeGet('preloader'); if(preloader) setTimeout(()=>{preloader.style.display='none';},400);

    updateLikeButtonUI();
});
