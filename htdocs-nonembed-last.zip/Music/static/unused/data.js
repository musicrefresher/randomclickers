var playlists = [
 {
      "name": "most-viewed",
      "id": "PL15B1E77BB5708555",
      "max": 543
    },
    {
      "name": "billboard",
      "id": "PL55713C70BA91BD6E",
      "max": 200
    },
    {
      "name": "latest",
      "id": "PLFgquLnL59akA2PflFpeQG9L01VFg90wS",
      "max": 100
    },
    {
      "name": "popular-music-videos",
      "id": "PLFgquLnL59alCl_2TQvOiD5Vgm1hCaGSI",
      "max": 200
    },
    {
      "name": "top-hits-this-week",
      "id": "PLw-VjHDlEOgvWPpRBs9FRGgJcKpDimTqf",
      "max": 130
    },
{
      "name": "russian-songs",
      "id": "PLOwSo8kHs4XR447QoOO4csKctRnCYOvvR",
      "max": 543
    },
{
      "name": "MR.BEAN",
      "id": "PL7A7C47763944A32C",
      "max": 543
    },
    {
      "name": "Pink-Panther",
      "id": "PLtS1NoNTpe8CYPxp59OECYEGiHZ0ds8pc",
      "max": 543
    },
    {
      "name": "Tom & Jerry",
      "id": "PLJYf0JdTApCqAbZImkQagXEuByh-b_7To",
      "max": 543
    },
{
      "name": "English Course",
      "id": "PLOCvbe7RB9fZMMtLM5IP-1oBVxjYownyc",
      "max": 543
    },
{
      "name": "Learning Python",
      "id": "PLu0W_9lII9agwh1XjRt242xIpHhPT2llg&cbrd=1",
      "max": 543
    },
{
      "name": "Learning Html Css",
      "id": "PLWKjhJtqVAbnSe1qUNMG7AbPmjIG54u88",
      "max": 543
    },
{
      "name": "World of Warcraft",
      "id": "PLY0KbDiiFYeP3_LM5Pf0hXzAZmT5txpk2&cbrd=1",
      "max": 543
    },
{
      "name": "Ethical HACKING",
      "id": "PLEiEAq2VkUUIkFUtoqL3geS1Op6GSX-f6&cbrd=1",
      "max": 543
    },
{
      "name": "Kali Linux",
      "id": "PLC7T9tZLj0SFn6wzvKdQir8rDb9VoU8j3&cbrd=1",
      "max": 543
    }

];