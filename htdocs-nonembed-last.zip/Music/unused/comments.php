<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "comments_db"; // Update with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['comment'])) {
    $comment = $_POST['comment'];

    // Insert comment into database
    $sql = "INSERT INTO comments (comment) VALUES ('$comment')";
    if ($conn->query($sql) === TRUE) {
        echo "Comment submitted successfully.";
    } else {
        echo "Error: " . $conn->error;
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Fetch last 5 comments
    $sql = "SELECT comment FROM comments ORDER BY id DESC LIMIT 5";
    $result = $conn->query($sql);

    $comments = [];
    while ($row = $result->fetch_assoc()) {
        $comments[] = $row;
    }

    echo json_encode($comments); // Return comments as JSON
}

$conn->close();
?>