var app = {
  videoList: ["dQw4w9WgXcQ","kxopViU98Xo","3JZ_D3ELwOQ"],
  index: null,
  likes: {}
};

var player;

function getRandomIndex(){return Math.floor(Math.random()*app.videoList.length);}
function updateLikeUI(i){/*...همان تابع قبلی*/}
function onYouTubeIframeAPIReady(){
  player = new YT.Player('player',{
    height:'360', width:'640',
    videoId: app.videoList[getRandomIndex()],
    playerVars:{autoplay:1,controls:1,mute:1,rel:0,showinfo:0}
  });
}

var tag=document.createElement('script');
tag.src="https://www.youtube.com/iframe_api";
document.getElementsByTagName('script')[0].parentNode.insertBefore(tag,tag);
