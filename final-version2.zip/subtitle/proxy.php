<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$apiKey = "ntQzrE7GqnMFe7CIB1ertEyJrJxQzGD6";

$query = isset($_GET['query']) ? urlencode($_GET['query']) : 'action';

$url = "https://api.opensubtitles.com/api/v1/subtitles?languages=fa&query=$query&order_by=downloads&limit=50";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Api-Key: $apiKey",
    "User-Agent: MySubtitleApp v1.0",
    "Content-Type: application/json"
]);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// اضافه کردن گزینه دنبال کردن ریدایرکت‌ها
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);

$response = curl_exec($ch);

if (curl_errno($ch)) {
    echo json_encode(["error" => curl_error($ch)]);
} else {
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    if ($httpcode !== 200) {
        echo json_encode(["error" => "OpenSubtitles API returned HTTP code $httpcode", "response" => $response]);
    } else {
        echo $response;
    }
}
curl_close($ch);
?>
