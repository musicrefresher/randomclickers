<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "visitors";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$count_result = $conn->query("SELECT COUNT(*) as total FROM visits");
$total_visits = $count_result->fetch_assoc()['total'];

$visits_result = $conn->query("SELECT * FROM visits ORDER BY visit_time DESC LIMIT 100");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Website Stats Dashboard</title>
    <meta charset="UTF-8">
    <style>
        body { font-family: sans-serif; background: #f4f4f4; padding: 20px; }
        h1 { color: #333; }
        table { width: 100%; border-collapse: collapse; background: white; }
        th, td { border: 1px solid #ccc; padding: 8px; font-size: 14px; text-align: center; }
        th { background-color: #eee; }
        .stat-box { margin-bottom: 20px; padding: 10px; background: #fff; border: 1px solid #ccc; display: inline-block; }
    </style>
	
</head>
<body>

<h1>📊 Website Statistics Dashboard</h1>

<div class="stat-box">
    <strong>Total Visits:</strong> <?= $total_visits ?>
</div>

<h2>📝 Last 100 Visits</h2>
<table>
    <tr>
        <th>IP</th>
        <th>User Agent</th>
        <th>Page URL</th>
        <th>Referrer</th>
        <th>Visit Time</th>
        <th>Duration (seconds)</th>
    </tr>
    <?php while($row = $visits_result->fetch_assoc()): ?>
    <tr>
        <td><?= htmlspecialchars($row['ip']) ?></td>
        <td><?= htmlspecialchars(substr($row['user_agent'], 0, 40)) ?>...</td>
        <td><?= htmlspecialchars($row['page_url']) ?></td>
        <td><?= htmlspecialchars($row['referrer']) ?></td>
        <td><?= $row['visit_time'] ?></td>
        <td><?= $row['duration_seconds'] ?></td>
    </tr>
    <?php endwhile; ?>
</table>

</body>
</html>
<?php
$conn->close();
?>
