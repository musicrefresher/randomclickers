const smartToggle = document.getElementById("smartModeToggle");
const likeBtn = document.getElementById("likeButton");
const playerIframe = document.getElementById("player");

function activateSmartMode() {
  document.addEventListener("mousedown", onDocumentMouseDown);
  document.addEventListener("contextmenu", onDocumentContextMenu);
  document.body.classList.add("smart-mode");
}

function deactivateSmartMode() {
  document.removeEventListener("mousedown", onDocumentMouseDown);
  document.removeEventListener("contextmenu", onDocumentContextMenu);
  document.body.classList.remove("smart-mode");
}

function onDocumentMouseDown(e) {
  if (!smartToggle.checked) return;

  // میخوای کلیک روی iframe نادیده گرفته بشه؟ اگر نه، خط بعد رو بردار
  if (playerIframe && playerIframe.contains(e.target)) return;

  e.preventDefault();

  if (e.button === 0) {
    // کلیک چپ: رفرش صفحه
    window.location.reload();
  } else if (e.button === 2) {
    // کلیک راست: کلیک روی دکمه لایک
    if (likeBtn) likeBtn.click();
  }
}

function onDocumentContextMenu(e) {
  if (!smartToggle.checked) return;
  e.preventDefault();
}

// بارگذاری و ذخیره حالت smartToggle در localStorage
window.addEventListener("DOMContentLoaded", () => {
  let savedMode = localStorage.getItem("smartBoxMode");
  if (savedMode === null) {
    savedMode = "enabled";
    localStorage.setItem("smartBoxMode", savedMode);
  }

  smartToggle.checked = (savedMode === "enabled");

  if (smartToggle.checked) {
    activateSmartMode();
  } else {
    deactivateSmartMode();
  }
});

// تغییر چک‌باکس
smartToggle.addEventListener("change", () => {
  if (smartToggle.checked) {
    localStorage.setItem("smartBoxMode", "enabled");
    activateSmartMode();
  } else {
    localStorage.setItem("smartBoxMode", "disabled");
    deactivateSmartMode();
  }
});
