var auth2;  // The Google Auth object

function startApp() {
  gapi.load('auth2', function() {
    auth2 = gapi.auth2.init({
      client_id: '970567680710-tup9q0dqn5kkf5hk72ehkqbom73dsksa.apps.googleusercontent.com',  // Replace with your Client ID
      scope: 'https://www.googleapis.com/auth/youtube.readonly',
      ux_mode: 'redirect',  // Enables redirect-based authentication
      redirect_uri: 'https://randomclickers.com/oauth2callback'  // Make sure this matches your Google Console settings
    });

    document.getElementById('loginButton').addEventListener('click', function() {
      auth2.signIn().then(function(user) {
        console.log('User signed in');
      }).catch(function(error) {
        console.error('Sign-in error:', error);
        document.getElementById('status').innerHTML = `<p>Error: ${error.error}</p>`;
      });
    });
  });
}

startApp();
