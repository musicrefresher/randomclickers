document.addEventListener("DOMContentLoaded", function() {
    const loginButton = document.getElementById("google-login");
    const profilePic = document.getElementById("profile-pic");
    const accessToken = localStorage.getItem("access_token");

    if (accessToken) {
        fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
            headers: { "Authorization": `Bearer ${accessToken}` }
        })
        .then(response => response.json())
        .then(data => {
            if (data.picture) {
                profilePic.src = data.picture;
                profilePic.style.display = "inline-block"; // Show profile picture
                loginButton.style.display = "none"; // Hide login button
                loadYouTubePlayer("dQw4w9WgXcQ"); // Load YouTube player with a sample video
            }
        })
        .catch(error => {
            console.error("Error fetching user info:", error);
            localStorage.removeItem("access_token");
        });
    }

    loginButton.addEventListener("click", function() {
        const clientId = "970567680710-tup9q0dqn5kkf5hk72ehkqbom73dsksa.apps.googleusercontent.com";
        const redirectUri = "https://randomclickers/oauth2callback";
        const scope = "https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/youtube.readonly";
        const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?response_type=token&client_id=${clientId}&redirect_uri=${redirectUri}&scope=${encodeURIComponent(scope)}&prompt=consent`;

        window.location.href = authUrl;
    });

    function loadYouTubePlayer(videoId) {
        let tag = document.createElement('script');
        tag.src = "https://www.youtube.com/iframe_api";
        let firstScriptTag = document.getElementsByTagName('script')[0];
        firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

        window.onYouTubeIframeAPIReady = function() {
            new YT.Player('player', {
                height: '315',
                width: '560',
                videoId: videoId,
                playerVars: {
                    'autoplay': 1,
                    'modestbranding': 1,
                    'rel': 0,
                    'playsinline': 1
                },
                events: {
                    'onReady': onPlayerReady,
                    'onError': onPlayerError
                }
            });
        };
    }

    function onPlayerReady(event) {
        event.target.playVideo();
    }

    function onPlayerError(event) {
        console.error("YouTube Player Error:", event.data);
    }
});
