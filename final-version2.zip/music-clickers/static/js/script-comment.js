document.addEventListener('DOMContentLoaded', function() {
    loadComments(); // Load comments when the page loads
  });

  function toggleCommentBox() {
    const commentContainer = document.getElementById('commentContainer');
    const toggleButton = document.getElementById('toggleButton');

    // Toggle visibility of the comment box
    if (commentContainer.style.display === 'none' || commentContainer.style.display === '') {
      commentContainer.style.display = 'block';
      toggleButton.textContent = 'Close Comments';
    } else {
      commentContainer.style.display = 'none';
      toggleButton.textContent = 'Show Comments';
    }
  }

  function submitComment() {
    const commentInput = document.getElementById('comment');
    const comment = commentInput.value.trim();
    
    if (comment) {
      // Create an AJAX request to send the comment to the backend
      const xhr = new XMLHttpRequest();
      xhr.open('POST', 'comments.php', true);
      xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      
      xhr.onload = function () {
        if (xhr.status === 200) {
          commentInput.value = '';  // Clear the input field after submission
          loadComments();  // Reload the comments dynamically after submitting a new one
        }
      };

      // Send the comment to the backend
      xhr.send('comment=' + encodeURIComponent(comment));
    } else {
      alert('Please enter a comment.');
    }
  }

  function loadComments() {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', 'comments.php', true);
    
    xhr.onload = function () {
      if (xhr.status === 200) {
        const comments = JSON.parse(xhr.responseText);
        refreshComments(comments);  // Refresh the comment list
      }
    };
    
    xhr.send();  // No data is sent, just retrieving comments
  }

  function refreshComments(comments) {
    const commentSection = document.getElementById('commentSection');
    commentSection.innerHTML = '';  // Clear current comment list
    
    comments.forEach(comment => {
      const commentItem = document.createElement('div');
      commentItem.className = 'mini-comment-item';
      commentItem.textContent = comment.comment;  // Display the comment
      commentSection.appendChild(commentItem);
    });
  }