<?php
// Database connection
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "active";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("DB connection error");
}

// Optional: Remove inactive visitors older than 60 seconds
$conn->query("DELETE FROM active_visitors WHERE last_active < NOW() - INTERVAL 60 SECOND");

// Count active users
$result = $conn->query("SELECT COUNT(*) AS total FROM active_visitors");
$row = $result->fetch_assoc();
$active = (int)$row['total'];

// If fewer than 10 users, redirect to waiting page
if ($active < 10) {
    header("Location: /index.html");
    exit();
}

// Otherwise, show the actual Enter page
// You can either:
// 1) redirect to index.html inside /Enter (if you want static file)
// header("Location: /enter/index.html");
// exit();

// OR

// 2) serve index.html content here (read and output file)
echo file_get_contents('index.html');
?>
