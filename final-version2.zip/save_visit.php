<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "visitors";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    die("Connection failed: " . $conn->connect_error);
}

$ip = $_SERVER['REMOTE_ADDR'];
$user_agent = $_POST['user_agent'];
$page_url = $_POST['page_url'];
$referrer = $_POST['referrer'];
$visit_time = date("Y-m-d H:i:s");
$duration = intval($_POST['duration']);

$stmt = $conn->prepare("INSERT INTO visits (ip, user_agent, page_url, referrer, visit_time, duration_seconds) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssi", $ip, $user_agent, $page_url, $referrer, $visit_time, $duration);
$stmt->execute();
$stmt->close();
$conn->close();
echo "OK";
?>
