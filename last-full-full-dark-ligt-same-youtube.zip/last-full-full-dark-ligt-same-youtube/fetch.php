<?php
/**
 * fetch.php - YouTube Playlist Fetcher
 * Returns JSON list of video IDs from a YouTube playlist
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

// Disable error display - log instead
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// Wrap everything in try-catch to prevent HTML error output
try {
    // Get playlist ID
    $playlistId = isset($_GET['playlist']) ? trim($_GET['playlist']) : '';
    
    if (empty($playlistId)) {
        throw new Exception('Playlist ID is required');
    }
    
    // YouTube Data API v3 Key
    // 👇 این کلید را از Google Cloud Console بگیرید
    $apiKey = getApiKey();
    
    if (empty($apiKey)) {
        throw new Exception('YouTube API key is not configured');
    }
    
    // Cache settings
    $cacheFile = __DIR__ . '/cache/' . preg_replace('/[^a-zA-Z0-9_\-]/', '_', $playlistId) . '.json';
    $cacheTTL = 3600; // 1 hour
    
    // Create cache directory if not exists
    $cacheDir = __DIR__ . '/cache';
    if (!is_dir($cacheDir)) {
        @mkdir($cacheDir, 0755, true);
    }
    
    // Check cache
    if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < $cacheTTL) {
        $cached = file_get_contents($cacheFile);
        if ($cached !== false) {
            echo $cached;
            exit;
        }
    }
    
    // Fetch from YouTube API with pagination
    $videoIds = [];
    $nextPageToken = '';
    $maxResults = 50;
    $totalFetched = 0;
    $maxVideos = 500; // Safety limit
    
    do {
        $url = 'https://www.googleapis.com/youtube/v3/playlistItems?' . http_build_query([
            'part'       => 'contentDetails',
            'maxResults' => $maxResults,
            'playlistId' => $playlistId,
            'pageToken'  => $nextPageToken,
            'key'        => $apiKey
        ]);
        
        $response = httpRequest($url);
        $data = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('Invalid response from YouTube API: ' . json_last_error_msg());
        }
        
        if (isset($data['error'])) {
            throw new Exception('YouTube API Error: ' . ($data['error']['message'] ?? 'Unknown'));
        }
        
        if (!isset($data['items']) || !is_array($data['items'])) {
            break;
        }
        
        foreach ($data['items'] as $item) {
            if (isset($item['contentDetails']['videoId'])) {
                $videoIds[] = $item['contentDetails']['videoId'];
                $totalFetched++;
                if ($totalFetched >= $maxVideos) break 2;
            }
        }
        
        $nextPageToken = $data['nextPageToken'] ?? '';
        
    } while (!empty($nextPageToken));
    
    if (empty($videoIds)) {
        throw new Exception('No videos found in this playlist (check playlist ID and privacy settings)');
    }
    
    // Return as JSON
    $jsonOutput = json_encode($videoIds, JSON_UNESCAPED_UNICODE);
    
    if ($jsonOutput === false) {
        throw new Exception('JSON encoding failed: ' . json_last_error_msg());
    }
    
    // Save to cache
    @file_put_contents($cacheFile, $jsonOutput);
    
    echo $jsonOutput;
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => true,
        'message' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}

/**
 * Get API key from settings file or environment
 */
function getApiKey(): string {
    // 1) Try environment variable
    if (!empty(getenv('YOUTUBE_API_KEY'))) {
        return getenv('YOUTUBE_API_KEY');
    }
    
    // 2) Try local config file (create this file separately)
    $configFile = __DIR__ . '/config.php';
    if (file_exists($configFile)) {
        $config = include $configFile;
        if (is_array($config) && !empty($config['youtube_api_key'])) {
            return $config['youtube_api_key'];
        }
    }
    
    // 3) Try .env file
    $envFile = __DIR__ . '/.env';
    if (file_exists($envFile)) {
        $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        foreach ($lines as $line) {
            if (strpos($line, '#') === 0) continue;
            if (strpos($line, '=') !== false) {
                list($key, $value) = explode('=', $line, 2);
                if (trim($key) === 'YOUTUBE_API_KEY') {
                    return trim($value);
                }
            }
        }
    }
    
    return '';
}

/**
 * HTTP request using cURL or file_get_contents as fallback
 */
function httpRequest(string $url): string {
    if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_USERAGENT      => 'MusicClickers/3.0',
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($response === false) {
            throw new Exception('cURL error: ' . $error);
        }
        if ($httpCode >= 400) {
            throw new Exception('HTTP ' . $httpCode . ' from YouTube');
        }
        return $response;
    }
    
    // Fallback
    $context = stream_context_create([
        'http' => [
            'timeout' => 15,
            'ignore_errors' => true,
            'header' => "User-Agent: MusicClickers/3.0\r\n"
        ]
    ]);
    $response = @file_get_contents($url, false, $context);
    if ($response === false) {
        throw new Exception('Failed to fetch from YouTube API');
    }
    return $response;
}