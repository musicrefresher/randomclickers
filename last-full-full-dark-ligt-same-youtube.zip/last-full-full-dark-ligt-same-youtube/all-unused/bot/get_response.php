<?php
// متن کاربر
$userMessage = trim($_POST["message"] ?? "");

// تابع پیدا کردن مشابه‌ترین سوال
function findSimilarAnswer($userMessage, $pairsFile) {
    if (!file_exists($pairsFile)) return null;

    $pairs = file($pairsFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $bestMatch = null;
    $highestSimilarity = 0;

    foreach ($pairs as $pair) {
        list($q, $a) = explode(" ::: ", $pair, 2);
        similar_text(mb_strtolower($q), mb_strtolower($userMessage), $percent);
        if ($percent > $highestSimilarity) {
            $highestSimilarity = $percent;
            $bestMatch = $a;
        }
    }

    // اگر درصد شباهت بالای 95% بود، همون جواب رو بده
    return ($highestSimilarity >= 90) ? $bestMatch : null;
}

// 1. بررسی اینکه مشابه لایک‌شده‌ای وجود دارد یا نه
$answer = findSimilarAnswer($userMessage, "correct_pairs.txt");
if ($answer) {
    echo $answer;
    exit;
}

// 2. اگر مشابه پیدا نشد → جواب رندوم از messages.txt
$messages_file = "messages.txt";
if (!file_exists($messages_file)) {
    echo "پیامی وجود ندارد.";
    exit;
}

$messages = file($messages_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
if (empty($messages)) {
    echo "پیامی وجود ندارد.";
    exit;
}

shuffle($messages);
echo $messages[0];
