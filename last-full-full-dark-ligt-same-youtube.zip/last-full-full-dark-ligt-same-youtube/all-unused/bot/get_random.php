<?php
$userMessage = trim($_POST["message"] ?? "");

// اگر متن کاربر خالی است، از حالت قدیمی (تصادفی) استفاده می‌کنیم
if (!$userMessage) {
    $messages = file_exists("messages.txt") ? file("messages.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];
    if (empty($messages)) {
        echo "پیامی وجود ندارد.";
        exit;
    }
    shuffle($messages);
    echo $messages[0];
    exit;
}

// بررسی اینکه آیا سوال مشابهی قبلاً لایک شده یا نه
if (file_exists("correct_pairs.txt")) {
    $pairs = file("correct_pairs.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($pairs as $pair) {
        list($q, $a) = explode(" ::: ", $pair, 2);
        if (mb_strtolower($q) === mb_strtolower($userMessage)) {
            echo $a; // همان جواب قبلی را برمی‌گردانیم
            exit;
        }
    }
}

// اگر سوال جدید بود → جواب تصادفی بده
$messages = file_exists("messages.txt") ? file("messages.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];
if (empty($messages)) {
    echo "پیامی وجود ندارد.";
    exit;
}
shuffle($messages);
echo $messages[0];
