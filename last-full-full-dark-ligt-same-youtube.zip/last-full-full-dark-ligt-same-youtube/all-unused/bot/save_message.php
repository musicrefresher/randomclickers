<?php
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["message"])) {
    $message = trim($_POST["message"]);

    // بررسی اینکه پیام خالی نباشه
    if ($message === "") {
        http_response_code(400);
        echo "پیام خالی است.";
        exit;
    }

    // پاک‌سازی پیام از HTML و اسکریپت‌های مخرب
    $message = strip_tags($message);         // حذف تگ‌های HTML
    $message = htmlspecialchars($message);   // تبدیل کاراکترهای خاص به HTML entities

    // ذخیره در فایل
    $file = "messages.txt";
    file_put_contents($file, $message . PHP_EOL, FILE_APPEND | LOCK_EX);

    // پاسخ موفق
    http_response_code(200);
    echo "پیام با موفقیت ذخیره شد.";
} else {
    http_response_code(405);
    echo "دسترسی غیرمجاز.";
}
?>
