<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $userMessage = trim($_POST["user_message"] ?? "");
    $botMessage  = trim($_POST["bot_message"] ?? "");
    $action = $_POST["action"] ?? "";

    if ($userMessage && $botMessage && ($action === "like" || $action === "dislike")) {
        $file = $action === "like" ? "correct_pairs.txt" : "incorrect_pairs.txt";

        // ذخیره به صورت "سوال ::: جواب"
        $pair = $userMessage . " ::: " . $botMessage;
        file_put_contents($file, $pair . PHP_EOL, FILE_APPEND | LOCK_EX);

        echo "OK";
    } else {
        http_response_code(400);
        echo "Invalid input";
    }
} else {
    http_response_code(405);
    echo "Method not allowed";
}
