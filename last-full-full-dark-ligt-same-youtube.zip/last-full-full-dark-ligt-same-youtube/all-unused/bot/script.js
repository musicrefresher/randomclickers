const chatBox = document.getElementById("chatBox");
const userInput = document.getElementById("userInput");

// استیکرهای رندوم برای ربات
const botStickers = ["🫣", "🫨", "🥴", "😑", "😂", "🤔", "🙄", "😅", "🤣", "🕵️"];

// ذخیره پیام آخر کاربر
let lastUserMessage = "";

// تابع اضافه کردن پیام
function appendMessage(text, sender, sticker = "", showButtons = false) {
  const div = document.createElement("div");
  div.className = `message ${sender}`;

  let html = `<span class="message-text">${text}</span>`;
  if (sticker) html += `<span class="sticker">${sticker}</span>`;

  if (showButtons && sender === "bot") {
    html += `
      <span class="like-dislike-inline">
        <button class="like-btn"><i class="fas fa-thumbs-up"></i></button>
        <button class="dislike-btn"><i class="fas fa-thumbs-down"></i></button>
      </span>
    `;
  }

  div.innerHTML = html;
  chatBox.appendChild(div);
  chatBox.scrollTop = chatBox.scrollHeight;

  // افزودن رویداد کلیک برای دکمه‌ها
  if (showButtons && sender === "bot") {
    const likeBtn = div.querySelector(".like-btn");
    const dislikeBtn = div.querySelector(".dislike-btn");

    likeBtn.addEventListener("click", () => {
      sendFeedback(lastUserMessage, text, "like");
      likeBtn.disabled = true;
      dislikeBtn.disabled = true;
    });

    dislikeBtn.addEventListener("click", () => {
      sendFeedback(lastUserMessage, text, "dislike");
      likeBtn.disabled = true;
      dislikeBtn.disabled = true;
    });
  }
}

// ارسال پیام کاربر
function sendMessage() {
  const text = userInput.value.trim();
  if (!text) return;

  appendMessage(text, "user");
  lastUserMessage = text;  // ذخیره پیام کاربر
  userInput.value = "";
  userInput.disabled = true;

  // ذخیره پیام کاربر
  fetch("save_message.php", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: "message=" + encodeURIComponent(text)
  }).then(() => {
    setTimeout(() => getBotResponse(), 1000);
  }).catch(() => {
    appendMessage("خطا در ذخیره پیام 😓", "bot", "⚠️");
    userInput.disabled = false;
  });
}

// گرفتن پاسخ رندوم از فایل
function getBotResponse() {
  fetch("get_random.php")
    .then(res => res.text())
    .then(text => {
      const messages = text.split("|").map(s => s.trim()).filter(Boolean);
      const message = messages[Math.floor(Math.random() * messages.length)] || "سلام!";
      const sticker = botStickers[Math.floor(Math.random() * botStickers.length)];
      typeSlowly(message, "bot", sticker, lastUserMessage);
    }).catch(() => {
      appendMessage("خطا در دریافت پاسخ 😞", "bot", "⚠️");
      userInput.disabled = false;
    });
}

function typeSlowly(text, sender, sticker, userMessage = "") {
  let i = 0;
  let currentText = "";
  userInput.disabled = true;

  function typing() {
    if (i <= text.length) {
      currentText = text.substring(0, i);

      if (chatBox.lastChild && chatBox.lastChild.classList.contains("typing")) {
        const messageText = chatBox.lastChild.querySelector(".message-text");
        if (messageText) {
          messageText.textContent = currentText;
        }
      } else {
        const div = document.createElement("div");
        div.className = `message ${sender} typing`;

        div.innerHTML = `
          <span class="message-text">${currentText}</span>
          ${sticker ? `<span class="sticker">${sticker}</span>` : ""}
          ${sender === "bot" ? `
            <span class="like-dislike-inline">
              <button class="like-btn"><i class="fas fa-thumbs-up"></i></button>
              <button class="dislike-btn"><i class="fas fa-thumbs-down"></i></button>
            </span>
          ` : ""}
        `;

        chatBox.appendChild(div);
      }

      chatBox.scrollTop = chatBox.scrollHeight;
      i++;
      setTimeout(typing, 40);
    } else {
      // پایان تایپ
      const msgElem = chatBox.lastChild;
      if (msgElem && msgElem.classList.contains("typing")) {
        msgElem.classList.remove("typing");

        if (sender === "bot") {
          const likeBtn = msgElem.querySelector(".like-btn");
          const dislikeBtn = msgElem.querySelector(".dislike-btn");

          if (likeBtn && dislikeBtn) {
            likeBtn.addEventListener("click", () => {
              sendFeedback(userMessage, text, "like");
              likeBtn.classList.add("liked");
              dislikeBtn.classList.remove("disliked");
              likeBtn.disabled = true;
              dislikeBtn.disabled = true;
            });

            dislikeBtn.addEventListener("click", () => {
              sendFeedback(userMessage, text, "dislike");
              dislikeBtn.classList.add("disliked");
              likeBtn.classList.remove("liked");
              likeBtn.disabled = true;
              dislikeBtn.disabled = true;
            });
          }
        }
      }

      userInput.disabled = false;
      userInput.focus();
    }
  }

  typing();
}

function sendFeedback(userMessage, botMessage, action) {
  fetch("save_feedback.php", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `user_message=${encodeURIComponent(userMessage)}&bot_message=${encodeURIComponent(botMessage)}&action=${action}`
  })
  .then(res => {
    if (!res.ok) throw new Error("خطا در ارسال بازخورد");
    return res.text();
  })
  .then(data => console.log("Feedback sent:", data))
  .catch(err => console.warn(err));
}

// ارسال با Enter
userInput.addEventListener("keydown", e => {
  if (e.key === "Enter") sendMessage();
});
