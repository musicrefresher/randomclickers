<?php
// config.php - ذخیره کلید API به صورت امن
// این فایل را در .htaccess یا gitignore قرار دهید

return [
    'youtube_api_key' => 'AIzaSyDbyXlxvwnazhi3nxnwdm0t2YhzcKwKHHA'
];