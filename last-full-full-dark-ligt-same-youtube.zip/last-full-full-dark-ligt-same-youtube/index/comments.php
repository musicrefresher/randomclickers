<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit(); }

$dataFile = __DIR__ . '/comments_data.json';

function loadComments($file) {
    if (!file_exists($file)) return [];
    $content = file_get_contents($file);
    return json_decode($content, true) ?: [];
}

function saveComments($file, $data) {
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

function sanitize($str) {
    return htmlspecialchars(trim($str), ENT_QUOTES, 'UTF-8');
}

$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// List comments for a video
if ($method === 'GET' && $action === 'list') {
    $videoId = $_GET['videoId'] ?? '';
    if (!$videoId) { echo json_encode(['error' => 'videoId required']); exit; }
    
    $comments = loadComments($dataFile);
    $videoComments = $comments[$videoId] ?? [];
    usort($videoComments, fn($a, $b) => $b['timestamp'] - $a['timestamp']);
    echo json_encode(['comments' => $videoComments]);
    exit;
}

// Add new comment
if ($method === 'POST' && $action === 'add') {
    $input = json_decode(file_get_contents('php://input'), true);
    $videoId = sanitize($input['videoId'] ?? '');
    $name    = sanitize($input['name'] ?? '');
    $text    = sanitize($input['text'] ?? '');
    
    if (!$videoId || !$name || !$text) { echo json_encode(['error' => 'All fields are required']); exit; }
    if (mb_strlen($name) > 50 || mb_strlen($text) > 1000) { echo json_encode(['error' => 'Text too long']); exit; }
    
    $bannedWords = ['spam', 'http://', 'https://'];
    foreach ($bannedWords as $word) {
        if (stripos($text, $word) !== false) { echo json_encode(['error' => 'Links are not allowed']); exit; }
    }
    
    $comments = loadComments($dataFile);
    if (!isset($comments[$videoId])) $comments[$videoId] = [];
    
    $newComment = [
        'id'        => uniqid('c_', true),
        'name'      => $name,
        'text'      => $text,
        'timestamp' => time(),
        'likes'     => 0,
        'ip'        => md5($_SERVER['REMOTE_ADDR'] ?? '')
    ];
    
    array_unshift($comments[$videoId], $newComment);
    
    if (count($comments[$videoId]) > 100) {
        $comments[$videoId] = array_slice($comments[$videoId], 0, 100);
    }
    
    saveComments($dataFile, $comments);
    echo json_encode(['success' => true, 'comment' => $newComment]);
    exit;
}

// Like a comment
if ($method === 'POST' && $action === 'like') {
    $input = json_decode(file_get_contents('php://input'), true);
    $videoId   = sanitize($input['videoId'] ?? '');
    $commentId = sanitize($input['commentId'] ?? '');
    
    $comments = loadComments($dataFile);
    if (isset($comments[$videoId])) {
        foreach ($comments[$videoId] as &$comment) {
            if ($comment['id'] === $commentId) {
                $comment['likes'] = ($comment['likes'] ?? 0) + 1;
                saveComments($dataFile, $comments);
                echo json_encode(['success' => true, 'likes' => $comment['likes']]);
                exit;
            }
        }
    }
    echo json_encode(['error' => 'Comment not found']);
    exit;
}

// Delete own comment
if ($method === 'POST' && $action === 'delete') {
    $input = json_decode(file_get_contents('php://input'), true);
    $videoId   = sanitize($input['videoId'] ?? '');
    $commentId = sanitize($input['commentId'] ?? '');
    $userIp    = md5($_SERVER['REMOTE_ADDR'] ?? '');
    
    $comments = loadComments($dataFile);
    if (isset($comments[$videoId])) {
        foreach ($comments[$videoId] as $key => $comment) {
            if ($comment['id'] === $commentId && ($comment['ip'] ?? '') === $userIp) {
                array_splice($comments[$videoId], $key, 1);
                saveComments($dataFile, $comments);
                echo json_encode(['success' => true]);
                exit;
            }
        }
    }
    echo json_encode(['error' => 'Permission denied']);
    exit;
}

echo json_encode(['error' => 'Invalid request']);