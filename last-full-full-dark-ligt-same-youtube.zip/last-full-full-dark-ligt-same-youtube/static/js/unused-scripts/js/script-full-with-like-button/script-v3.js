var app = {
    playlist: {
        id: 'PLt1KecuO3RM3HjHWHVRxCjdqQDP9I7L2i&si=DWZACY0FDOqRMpci',
        max: 100,
    },
    index: null,
    likes: {},
    baseURL: 'https://www.youtube.com/embed/?list={0}&index={1}',
    queryStrings: '&amp;t=15&amp;wmode=transparent&amp;autoplay=1&amp;rel=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;autohide=1&amp;controls=0',
    iframeSrc: '',
};

// ذخیره لایک‌ها در Local Storage
var saveLikes = function() {
    localStorage.setItem('videoLikes', JSON.stringify(app.likes));
};

// بازیابی لایک‌ها از Local Storage
var loadLikes = function() {
    var savedLikes = localStorage.getItem('videoLikes');
    if (savedLikes) {
        app.likes = JSON.parse(savedLikes);
    }
};

var generateRandom = function(num) {
    return Math.floor(Math.random() * num);
};

var getNextIndex = function() {
    var weightedList = [];
    for (var i = 0; i < app.playlist.max; i++) {
        var weight = app.likes[i] ? app.likes[i] + 1 : 1;
        for (var j = 0; j < weight; j++) {
            weightedList.push(i);
        }
    }
    return weightedList[generateRandom(weightedList.length)];
};

String.prototype.format = function() {
    var string = this;
    for (var i = 0; i < arguments.length; i++) {
        var regexp = new RegExp('\\{' + i + '\\}', 'gi');
        string = string.replace(regexp, arguments[i]);
    }
    return string;
};

var setURL = function() {
    return app.baseURL.format(app.playlist.id, app.index) + app.queryStrings;
};

// Initialize
loadLikes();  // بازیابی لایک‌ها از Local Storage
app.index = getNextIndex();
app.iframeSrc = setURL();

$(function() {
    $('#player').attr('src', app.iframeSrc);

    $('#back').click(function() {
        app.index = app.index > 0 ? app.index - 1 : app.playlist.max - 1;
        app.iframeSrc = setURL();
        $('#player').attr('src', app.iframeSrc);
    });

    $('#forward').click(function() {
        app.index = getNextIndex();
        app.iframeSrc = setURL();
        $('#player').attr('src', app.iframeSrc);
    });

    $(document).click(function(event) {
        if (!$(event.target).closest('#player').length) {
            $('#likeButton').fadeIn();
        }
    });

    $('#likeButton').click(function() {
        if (!app.likes[app.index]) {
            app.likes[app.index] = 1;
        } else {
            app.likes[app.index]++;
        }
        saveLikes();  // ذخیره لایک‌ها در Local Storage
        $(this).fadeOut();
    });
});
