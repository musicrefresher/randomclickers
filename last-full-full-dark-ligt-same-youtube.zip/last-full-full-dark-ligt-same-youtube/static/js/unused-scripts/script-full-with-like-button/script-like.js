    var app = {
        playlist: {
            id: 'PLt1KecuO3RM3HjHWHVRxCjdqQDP9I7L2i',
            max: 200,
        },
        index: null,
        likes: {},
        baseURL: 'https://www.youtube.com/embed/?list={0}&index={1}',
        queryStrings: '&wmode=transparent&autoplay=1&rel=0&showinfo=0&iv_load_policy=3&showsearch=0&autohide=1&controls=0',
        iframeSrc: '',
    };

    // ذخیره لایک‌ها در Local Storage
    var saveLikes = function () {
        localStorage.setItem('videoLikes', JSON.stringify(app.likes));
    };

    // بازیابی لایک‌ها از Local Storage
    var loadLikes = function () {
        var savedLikes = localStorage.getItem('videoLikes');
        if (savedLikes) {
            app.likes = JSON.parse(savedLikes);
        }
    };

    var generateRandom = function (num) {
        return Math.floor(Math.random() * num);
    };

    var getNextIndex = function () {
        var weightedList = [];
        for (var i = 0; i < app.playlist.max; i++) {
            var weight = app.likes[i] ? 5 : 1;
            for (var j = 0; j < weight; j++) {
                weightedList.push(i);
            }
        }
        return weightedList[generateRandom(weightedList.length)];
    };

    String.prototype.format = function () {
        var string = this;
        for (var i = 0; i < arguments.length; i++) {
            var regexp = new RegExp('\\{' + i + '\\}', 'gi');
            string = string.replace(regexp, arguments[i]);
        }
        return string;
    };

    var setURL = function () {
        return app.baseURL.format(app.playlist.id, app.index) + app.queryStrings;
    };

    // Initialize
    loadLikes();
    app.index = getNextIndex();
    app.iframeSrc = setURL();

    $(function () {
        $('#player').attr('src', app.iframeSrc);

        if (app.likes[app.index]) {
            $('#likeButton').addClass('liked');
            $('#likeButtonText').text("Liked");
            $('#likeIcon').html('&#xf164;').css('color', 'green');
        }

        $('#likeButton').click(function () {
    const buttonText = $("#likeButtonText").text();
    if (buttonText === "Like") {
        if (!app.likes[app.index]) {
            app.likes[app.index] = 1;
            saveLikes();
        }
        $('#likeIcon').html('&#xf164;').css('color', 'green');
        $('#likeButtonText').text("Liked");
        $('#likeButton').addClass('liked');
    }
});

$('#refreshButton').click(function () {
    app.index = getNextIndex();
    app.iframeSrc = setURL();
    $('#player').attr('src', app.iframeSrc);

    if (app.likes[app.index]) {
        $('#likeButton').addClass('liked');
        $('#likeButtonText').text("Liked");
        $('#likeIcon').html('&#xf164;').css('color', 'green');
    } else {
        $('#likeButton').removeClass('liked');
        $('#likeButtonText').text("Like");
        $('#likeIcon').html('&#xf087;').css('color', '');
    }
});
	});