var app = {
    playlist: {
        id: 'PLt1KecuO3RM3HjHWHVRxCjdqQDP9I7L2i&si=DWZACY0FDOqRMpci',
        max: 200,
    },
    index: null,
    likes: {},
    baseURL: 'https://www.youtube.com/embed/?list={0}&index={1}',
    queryStrings: '&amp;t=15&amp;wmode=transparent&amp;autoplay=1&amp;rel=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;autohide=1&amp;controls=0',
    iframeSrc: '',
    playlists: {
        'music video': 'PLt1KecuO3RM3HjHWHVRxCjdqQDP9I7L2i&si=DWZACY0FDOqRMpci',
        'movies': 'PLt1KecuO3RM3gSc52eLPrSakXCaX74A80&si=q_gL7KwZ8dbPFgzG',
        
    }
};

// ذخیره لایک‌ها و پلی‌لیست انتخابی در Local Storage
var saveState = function() {
    localStorage.setItem('videoLikes', JSON.stringify(app.likes));
    localStorage.setItem('lastPlaylist', app.playlist.id);
};

// بازیابی لایک‌ها و پلی‌لیست از Local Storage
var loadState = function() {
    var savedLikes = localStorage.getItem('videoLikes');
    if (savedLikes) app.likes = JSON.parse(savedLikes);
    var savedPlaylist = localStorage.getItem('lastPlaylist');
    if (savedPlaylist) app.playlist.id = savedPlaylist;
};


var generateRandom = function(num) {
    return Math.floor(Math.random() * num);
};

var getNextIndex = function() {
    var weightedList = [];
    for (var i = 0; i < app.playlist.max; i++) {
        var weight = app.likes[i] ? 5 : 1;  // Increase weight to 5 for liked videos
        for (var j = 0; j < weight; j++) {
            weightedList.push(i);
        }
    }
    return weightedList[generateRandom(weightedList.length)];
};

String.prototype.format = function() {
    var string = this;
    for (var i = 0; i < arguments.length; i++) {
        var regexp = new RegExp('\\{' + i + '\\}', 'gi');
        string = string.replace(regexp, arguments[i]);
    }
    return string;
};

var setURL = function() {
    return app.baseURL.format(app.playlist.id, app.index) + app.queryStrings;
};

// Initialize
loadLikes();  // بازیابی لایک‌ها از Local Storage
app.index = getNextIndex();
app.iframeSrc = setURL();

$(function() {
    $('#player').attr('src', app.iframeSrc);

    // Fade out the like button if already liked
    if (app.likes[app.index]) {
        $('#likeButton').fadeTo(0, 0.5);
    }

    $('#back').click(function() {
        app.index = app.index > 0 ? app.index - 1 : app.playlist.max - 1;
        app.iframeSrc = setURL();
        $('#player').attr('src', app.iframeSrc);

        // Adjust the like button opacity based on previous likes
        if (app.likes[app.index]) {
            $('#likeButton').fadeTo(200, 0.5);
        } else {
            $('#likeButton').fadeTo(200, 1);
        }
    });

    $('#forward').click(function() {
        app.index = getNextIndex();
        app.iframeSrc = setURL();
        $('#player').attr('src', app.iframeSrc);

        // Adjust the like button opacity based on previous likes
        if (app.likes[app.index]) {
            $('#likeButton').fadeTo(200, 0.5);
        } else {
            $('#likeButton').fadeTo(200, 1);
        }
    });

    $('#likeButton').click(function() {
        if (!app.likes[app.index]) {
            app.likes[app.index] = 1;
            saveLikes();  // ذخیره لایک‌ها در Local Storage
            $(this).fadeTo(200, 0.5);  // Fade the button to half opacity after liking
        }
    });
});

